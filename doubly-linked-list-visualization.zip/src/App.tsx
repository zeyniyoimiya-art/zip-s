import { Eye, Keyboard, MousePointerClick } from 'lucide-react';
import { SectionHeader } from './components/common';
import { Simulator } from './components/Simulator';
import { ComplexitySection, Footer, OrderSection, QuizSection, TipsSection } from './components/sections/Extras';
import { Hero, MemorySection, Nav, NodeSection } from './components/sections/Intro';
import { MethodsSection } from './components/sections/Methods';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050816] text-slate-200 selection:bg-violet-500/40">
      <Nav />
      <main>
        <Hero />
        <NodeSection />
        <MemorySection />

        <section id="simulador" className="relative scroll-mt-20 border-y border-slate-800/70 bg-gradient-to-b from-slate-950/80 via-[#070b1d] to-slate-950/80">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/60 to-transparent" />
          <div className="mx-auto max-w-[1560px] px-4 py-20 sm:px-6">
            <SectionHeader num="3" kicker="Interactivo" title="Simulador: ejecuta tu código paso a paso">
              Elige cualquier método con los valores que quieras. Verás al mismo tiempo el <b className="text-slate-200">dibujo de la lista</b>, la{' '}
              <b className="text-slate-200">línea exacta de tu código</b> que se está ejecutando y cómo cambia la{' '}
              <b className="text-slate-200">memoria real</b> (stack y heap).
            </SectionHeader>
            <div className="mb-6 grid gap-3 sm:grid-cols-3">
              {[
                [<MousePointerClick key="a" size={16} />, '1. Elige una operación', 'Los botones muestran la llamada exacta con tus valores.'],
                [<Keyboard key="b" size={16} />, '2. Avanza paso a paso', 'Usa Reproducir, la línea de tiempo o las flechas ← → del teclado.'],
                [<Eye key="c" size={16} />, '3. Observa los 3 paneles', 'Lo amarillo es lo que acaba de cambiar en ese paso.'],
              ].map(([icon, t, d], i) => (
                <div key={i} className="flex gap-3 rounded-xl border border-slate-800 bg-slate-900/40 p-3">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-yellow-400/15 text-yellow-300">{icon}</span>
                  <div>
                    <div className="text-sm font-bold text-white">{t}</div>
                    <div className="text-xs leading-snug text-slate-400">{d}</div>
                  </div>
                </div>
              ))}
            </div>
            <Simulator />
          </div>
        </section>

        <MethodsSection />
        <OrderSection />
        <ComplexitySection />
        <TipsSection />
        <QuizSection />
      </main>
      <Footer />
    </div>
  );
}
