export type MethodName =
  | 'agregarInicio'
  | 'agregarFinal'
  | 'eliminarInicio'
  | 'eliminarFinal'
  | 'buscarElemento'
  | 'insertarDespuesDe'
  | 'insertarAntesDe'
  | 'MostrarListaInicioFin'
  | 'MostrarListaFinInicio';

export interface CodeLine {
  id?: string;
  text: string;
}

/** Cada línea puede empezar con "@id|" para poder resaltarla desde el simulador. */
function parse(src: string): CodeLine[] {
  return src
    .replace(/^\n/, '')
    .replace(/\n\s*$/, '')
    .split('\n')
    .map((line) => {
      const m = line.match(/^@([\w-]+)\|(.*)$/);
      return m ? { id: m[1], text: m[2] } : { text: line };
    });
}

export const NODO_CODE = parse(`
public class NodoDobleD {

    int dato;
    NodoDobleD anterior;
    NodoDobleD siguiente;

    public NodoDobleD(int dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}
`);

export const CLASS_CODE = parse(`
public class ListaMetodoDoble {

@fields|    NodoDobleD inicio;
@fields2|    NodoDobleD fin;

@ctor|    public ListaMetodoDoble() {
@c1|        inicio = null;
@c2|        fin = null;
    }

@vacia|    public boolean Vacia() {
@v1|        return inicio == null;
    }

    // agregarInicio, agregarFinal, eliminarInicio,
    // eliminarFinal, buscarElemento, insertarDespuesDe,
    // insertarAntesDe, MostrarListaInicioFin, MostrarListaFinInicio
}
`);

export const METHOD_CODE: Record<MethodName, CodeLine[]> = {
  agregarInicio: parse(`
@sig|public void agregarInicio(int elemento) {
@new|    NodoDobleD nuevo = new NodoDobleD(elemento);
@if|    if (Vacia()) {
@i1|        inicio = nuevo;
@f1|        fin = nuevo;
    } else {
@a1|        nuevo.siguiente = inicio;
@a2|        inicio.anterior = nuevo;
@a3|        inicio = nuevo;
    }
@end|}
`),
  agregarFinal: parse(`
@sig|public void agregarFinal(int elemento) {
@new|    NodoDobleD nuevo = new NodoDobleD(elemento);
@if|    if (Vacia()) {
@i1|        inicio = nuevo;
@f1|        fin = nuevo;
    } else {
@a1|        fin.siguiente = nuevo;
@a2|        nuevo.anterior = fin;
@a3|        fin = nuevo;
    }
@end|}
`),
  eliminarInicio: parse(`
@sig|public void eliminarInicio() {
@if|    if (Vacia()) {
@err|        JOptionPane.showMessageDialog(null, "La lista está vacía", "ERROR", JOptionPane.ERROR_MESSAGE);
@ret|        return;
    }
@one|    if (inicio == fin) {
@n1|        inicio = null;
@n2|        fin = null;
    } else {
@a1|        inicio = inicio.siguiente;
@a2|        inicio.anterior = null;
    }
@ok|    JOptionPane.showMessageDialog(null, "Elemento eliminado del inicio", "ÉXITO", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
  eliminarFinal: parse(`
@sig|public void eliminarFinal() {
@if|    if (Vacia()) {
@err|        JOptionPane.showMessageDialog(null, "La lista está vacía", "ERROR", JOptionPane.ERROR_MESSAGE);
@ret|        return;
    }
@one|    if (inicio == fin) {
@n1|        inicio = null;
@n2|        fin = null;
    } else {
@a1|        fin = fin.anterior;
@a2|        fin.siguiente = null;
    }
@ok|    JOptionPane.showMessageDialog(null, "Elemento eliminado del final", "ÉXITO", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
  buscarElemento: parse(`
@sig|public void buscarElemento(int elemento) {
@if|    if (Vacia()) {
@err|        JOptionPane.showMessageDialog(null, "La lista está vacía", "ERROR", JOptionPane.ERROR_MESSAGE);
@ret|        return;
    }
@act|    NodoDobleD actual = inicio;
@pos|    int posicion = 1;
@enc|    boolean encontrado = false;
@while|    while (actual != null) {
@cmp|        if (actual.dato == elemento) {
@set|            encontrado = true;
@brk|            break;
        }
@adv|        actual = actual.siguiente;
@inc|        posicion++;
    }
@res|    if (encontrado) {
@found|        JOptionPane.showMessageDialog(null, "Elemento " + elemento + " encontrado en la posición " + posicion, "ENCONTRADO", JOptionPane.INFORMATION_MESSAGE);
    } else {
@nf|        JOptionPane.showMessageDialog(null, "Elemento " + elemento + " NO encontrado en la lista", "NO ENCONTRADO", JOptionPane.WARNING_MESSAGE);
    }
@end|}
`),
  insertarDespuesDe: parse(`
@sig|public void insertarDespuesDe(int valorReferencia, int nuevoValor) {
@if|    if (Vacia()) {
@err|        JOptionPane.showMessageDialog(null, "La lista está vacía, imposible insertar.", "LISTA VACÍA", JOptionPane.WARNING_MESSAGE);
@ret|        return;
    }
@act|    NodoDobleD actual = inicio;
@hal|    boolean hallado = false;
@while|    while (actual != null) {
@cmp|        if (actual.dato == valorReferencia) {
@set|            hallado = true;
@brk|            break;
        }
@adv|        actual = actual.siguiente;
    }
@nh|    if (!hallado) {
@nherr|        JOptionPane.showMessageDialog(null, "El elemento de referencia " + valorReferencia + " no se encuentra en la lista.", "NO ENCONTRADO", JOptionPane.WARNING_MESSAGE);
@nhret|        return;
    }
@new|    NodoDobleD nuevo = new NodoDobleD(nuevoValor);
@isfin|    if (actual == fin) {
@f1|        actual.siguiente = nuevo;
@f2|        nuevo.anterior = actual;
@f3|        fin = nuevo;
    } else {
@g1|        nuevo.siguiente = actual.siguiente;
@g2|        nuevo.anterior = actual;
@g3|        actual.siguiente.anterior = nuevo;
@g4|        actual.siguiente = nuevo;
    }
@ok|    JOptionPane.showMessageDialog(null, "Se insertó con éxito el valor " + nuevoValor + " después de " + valorReferencia, "INSERCIÓN EXITOSA", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
  insertarAntesDe: parse(`
@sig|public void insertarAntesDe(int valorReferencia, int nuevoValor) {
@if|    if (Vacia()) {
@err|        JOptionPane.showMessageDialog(null, "La lista está vacía, imposible insertar.", "LISTA VACÍA", JOptionPane.WARNING_MESSAGE);
@ret|        return;
    }
    // 1) Se busca el elemento X (valorReferencia) recorriendo desde inicio
@act|    NodoDobleD actual = inicio;
@hal|    boolean hallado = false;
@while|    while (actual != null) {
@cmp|        if (actual.dato == valorReferencia) {
@set|            hallado = true;
@brk|            break;
        }
@adv|        actual = actual.siguiente;
    }
@nh|    if (!hallado) {
@nherr|        JOptionPane.showMessageDialog(null, "El elemento de referencia " + valorReferencia + " no se encuentra en la lista.", "NO ENCONTRADO", JOptionPane.WARNING_MESSAGE);
@nhret|        return;
    }
    // 2) Se inserta el nuevo nodo antes del nodo encontrado
@new|    NodoDobleD nuevo = new NodoDobleD(nuevoValor);
@isini|    if (actual == inicio) {
        // Caso especial: X es el primero, el nuevo pasa a ser inicio
@i1|        nuevo.siguiente = inicio;
@i2|        inicio.anterior = nuevo;
@i3|        inicio = nuevo;
    } else {
        // Caso general: se reconectan los 4 punteros
@g1|        nuevo.anterior = actual.anterior;
@g2|        nuevo.siguiente = actual;
@g3|        actual.anterior.siguiente = nuevo;
@g4|        actual.anterior = nuevo;
    }
@ok|    JOptionPane.showMessageDialog(null, "Se insertó con éxito el valor " + nuevoValor + " antes de " + valorReferencia, "INSERCIÓN EXITOSA", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
  MostrarListaInicioFin: parse(`
@sig|public void MostrarListaInicioFin() {
@str|    String lista = "null <-> ";
@act|    NodoDobleD actual = inicio;
@while|    while (actual != null) {
@cat|        lista = lista + actual.dato + " <-> ";
@adv|        actual = actual.siguiente;
    }
@null|    lista = lista + "null";
@show|    JOptionPane.showMessageDialog(null, lista,
@show2|            "Lista de Inicio a Fin", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
  MostrarListaFinInicio: parse(`
@sig|public void MostrarListaFinInicio() {
@str|    String lista = "null <-> ";
@act|    NodoDobleD actual = fin;
@while|    while (actual != null) {
@cat|        lista = lista + actual.dato + " <-> ";
@adv|        actual = actual.anterior;
    }
@null|    lista = lista + "null";
@show|    JOptionPane.showMessageDialog(null, lista,
@show2|            "Lista de Fin a Inicio", JOptionPane.INFORMATION_MESSAGE);
@end|}
`),
};

export const METHOD_ORDER: MethodName[] = [
  'agregarInicio',
  'agregarFinal',
  'eliminarInicio',
  'eliminarFinal',
  'buscarElemento',
  'insertarDespuesDe',
  'insertarAntesDe',
  'MostrarListaInicioFin',
  'MostrarListaFinInicio',
];

export const METHOD_META: Record<
  MethodName,
  { signature: string; complexity: string; short: string; group: string }
> = {
  agregarInicio: {
    signature: 'agregarInicio(int elemento)',
    complexity: 'O(1)',
    short: 'Crea un nodo y lo pone al principio.',
    group: 'Agregar',
  },
  agregarFinal: {
    signature: 'agregarFinal(int elemento)',
    complexity: 'O(1)',
    short: 'Crea un nodo y lo pone al final (gracias a fin).',
    group: 'Agregar',
  },
  eliminarInicio: {
    signature: 'eliminarInicio()',
    complexity: 'O(1)',
    short: 'Quita el primer nodo.',
    group: 'Eliminar',
  },
  eliminarFinal: {
    signature: 'eliminarFinal()',
    complexity: 'O(1)',
    short: 'Quita el último nodo (gracias a anterior).',
    group: 'Eliminar',
  },
  buscarElemento: {
    signature: 'buscarElemento(int elemento)',
    complexity: 'O(n)',
    short: 'Recorre desde inicio hasta hallar el valor.',
    group: 'Buscar',
  },
  insertarDespuesDe: {
    signature: 'insertarDespuesDe(int valorReferencia, int nuevoValor)',
    complexity: 'O(n)',
    short: 'Busca X e inserta el nuevo a su derecha.',
    group: 'Insertar',
  },
  insertarAntesDe: {
    signature: 'insertarAntesDe(int valorReferencia, int nuevoValor)',
    complexity: 'O(n)',
    short: 'Busca X e inserta el nuevo a su izquierda.',
    group: 'Insertar',
  },
  MostrarListaInicioFin: {
    signature: 'MostrarListaInicioFin()',
    complexity: 'O(n)',
    short: 'Recorre con siguiente: de inicio a fin.',
    group: 'Recorrer',
  },
  MostrarListaFinInicio: {
    signature: 'MostrarListaFinInicio()',
    complexity: 'O(n)',
    short: 'Recorre con anterior: de fin a inicio.',
    group: 'Recorrer',
  },
};
