import type { MethodName } from './code';

/* ------------------------------------------------------------------ */
/*  Modelo de memoria                                                  */
/* ------------------------------------------------------------------ */

export type Addr = string;

export interface NodeData {
  addr: Addr;
  dato: number;
  anterior: Addr | null;
  siguiente: Addr | null;
}

export interface ListState {
  nodes: Record<Addr, NodeData>;
  inicio: Addr | null;
  fin: Addr | null;
}

export type VarValue =
  | { kind: 'ref'; type: string; value: Addr | null }
  | { kind: 'int'; value: number }
  | { kind: 'bool'; value: boolean }
  | { kind: 'str'; value: string };

export type DialogType = 'info' | 'error' | 'warning';

export interface DialogData {
  title: string;
  message: string;
  type: DialogType;
}

export interface Frame {
  state: ListState;
  vars: [string, VarValue][];
  line: string;
  title: string;
  message: string;
  /** orden visual de los nodos en la vista lógica */
  order: Addr[];
  /** nodos creados pero aún no enlazados (se dibujan arriba) */
  raised: Addr[];
  /** nodos inalcanzables (se dibujan abajo, esperando al GC) */
  garbage: Addr[];
  /** punteros que cambiaron en este paso: "inicio", "fin", "0x7A48.siguiente", "var:actual" */
  changed: string[];
  focus: Addr[];
  visited: Addr[];
  compare?: { addr: Addr; ok: boolean; text: string };
  dialog?: DialogData;
  created?: Addr;
  freed?: Addr[];
  nullSide?: 'left' | 'right';
  done?: boolean;
  method: MethodName | null;
}

export type Operation =
  | { method: 'agregarInicio' | 'agregarFinal' | 'buscarElemento'; value: number }
  | { method: 'eliminarInicio' | 'eliminarFinal' | 'MostrarListaInicioFin' | 'MostrarListaFinInicio' }
  | { method: 'insertarDespuesDe' | 'insertarAntesDe'; ref: number; value: number };

/* ------------------------------------------------------------------ */
/*  Heap simulado                                                      */
/* ------------------------------------------------------------------ */

export const HEAP_BASE = 0x7a00;
/** 24 bytes: tamaño típico de un NodoDobleD en una JVM de 64 bits */
export const SLOT_SIZE = 0x18;
export const HEAP_SLOTS = 24;
export const LIST_SLOT = 1;
export const OTHER_SLOTS: Record<number, string> = {
  4: 'String',
  9: 'Object[]',
  15: 'Integer',
  20: 'char[]',
};
export const MAX_NODES = 12;

export const slotAddr = (i: number): Addr =>
  '0x' + (HEAP_BASE + i * SLOT_SIZE).toString(16).toUpperCase();
export const slotOf = (a: Addr): number => Math.round((parseInt(a, 16) - HEAP_BASE) / SLOT_SIZE);
export const LIST_ADDR = slotAddr(LIST_SLOT);

const PALETTE = [
  '#f472b6', '#60a5fa', '#a3e635', '#fbbf24', '#c084fc', '#f87171',
  '#22d3ee', '#fda4af', '#818cf8', '#e879f9', '#2dd4bf', '#fde047',
  '#93c5fd', '#f9a8d4', '#86efac', '#fcd34d', '#a5b4fc', '#5eead4',
  '#f0abfc', '#bef264', '#7dd3fc', '#fdba74', '#d8b4fe', '#67e8f9',
];

export function nodeColor(a: Addr): string {
  const i = slotOf(a);
  if (Number.isNaN(i)) return '#94a3b8';
  return PALETTE[((i % PALETTE.length) + PALETTE.length) % PALETTE.length];
}

export function mulberry32(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function freeSlots(s: ListState): number[] {
  const used = new Set(Object.keys(s.nodes).map(slotOf));
  const out: number[] = [];
  for (let i = 0; i < HEAP_SLOTS; i++) {
    if (i === LIST_SLOT || i in OTHER_SLOTS || used.has(i)) continue;
    out.push(i);
  }
  return out;
}

export function emptyState(): ListState {
  return { nodes: {}, inicio: null, fin: null };
}

export function buildState(values: number[], rng: () => number = Math.random): ListState {
  const s = emptyState();
  let prev: Addr | null = null;
  for (const v of values) {
    const free = freeSlots(s);
    const a = slotAddr(free[Math.floor(rng() * free.length)]);
    s.nodes[a] = { addr: a, dato: v, anterior: prev, siguiente: null };
    if (prev !== null) s.nodes[prev].siguiente = a;
    else s.inicio = a;
    prev = a;
  }
  s.fin = prev;
  return s;
}

/** Construye una lista usando celdas concretas del heap (para ejemplos reproducibles). */
export function buildStateAt(values: number[], slots: number[]): ListState {
  const s = emptyState();
  let prev: Addr | null = null;
  values.forEach((v, i) => {
    const a = slotAddr(slots[i]);
    s.nodes[a] = { addr: a, dato: v, anterior: prev, siguiente: null };
    if (prev !== null) s.nodes[prev].siguiente = a;
    else s.inicio = a;
    prev = a;
  });
  s.fin = prev;
  return s;
}

/** Lista de ejemplo 10 ⇄ 20 ⇄ 30 ⇄ 40 con nodos bien dispersos en el heap. */
export const exampleState = (): ListState => buildStateAt([10, 20, 30, 40], [7, 3, 16, 19]);

export function cloneState(s: ListState): ListState {
  const nodes: Record<Addr, NodeData> = {};
  for (const k of Object.keys(s.nodes)) nodes[k] = { ...s.nodes[k] };
  return { nodes, inicio: s.inicio, fin: s.fin };
}

export function chainOrder(s: ListState): Addr[] {
  const out: Addr[] = [];
  const seen = new Set<Addr>();
  let cur = s.inicio;
  while (cur && !seen.has(cur) && s.nodes[cur]) {
    out.push(cur);
    seen.add(cur);
    cur = s.nodes[cur].siguiente;
  }
  for (const a of Object.keys(s.nodes)) if (!seen.has(a)) out.push(a);
  return out;
}

export function listValues(s: ListState): number[] {
  return chainOrder(s).map((a) => s.nodes[a].dato);
}

export function idleFrame(s: ListState, message?: string, title = 'Listo'): Frame {
  return {
    state: cloneState(s),
    vars: [],
    line: '',
    title,
    message:
      message ??
      'Elige una operación arriba. Cada paso mostrará qué línea de tu código se ejecuta y qué cambia en la memoria.',
    order: chainOrder(s),
    raised: [],
    garbage: [],
    changed: [],
    focus: [],
    visited: [],
    method: null,
    done: true,
  };
}

export function opLabel(op: Operation): string {
  switch (op.method) {
    case 'agregarInicio':
    case 'agregarFinal':
    case 'buscarElemento':
      return `${op.method}(${op.value})`;
    case 'insertarDespuesDe':
    case 'insertarAntesDe':
      return `${op.method}(${op.ref}, ${op.value})`;
    default:
      return `${op.method}()`;
  }
}

/* ------------------------------------------------------------------ */
/*  Grabador de pasos                                                  */
/* ------------------------------------------------------------------ */

const int = (value: number): VarValue => ({ kind: 'int', value });
const bool = (value: boolean): VarValue => ({ kind: 'bool', value });
const str = (value: string): VarValue => ({ kind: 'str', value });
const ref = (value: Addr | null): VarValue => ({ kind: 'ref', type: 'NodoDobleD', value });

class Rec {
  s: ListState;
  vars: [string, VarValue][] = [];
  frames: Frame[] = [];
  order: Addr[];
  raised: Addr[] = [];
  garbage: Addr[] = [];
  visited: Addr[] = [];
  nullSide: 'left' | 'right' = 'right';
  method: MethodName;
  rng: () => number;

  constructor(init: ListState, method: MethodName, rng: () => number) {
    this.s = cloneState(init);
    this.order = chainOrder(this.s);
    this.method = method;
    this.rng = rng;
  }

  set(name: string, v: VarValue) {
    const i = this.vars.findIndex(([n]) => n === name);
    if (i >= 0) this.vars[i] = [name, v];
    else this.vars.push([name, v]);
  }

  alloc(): Addr {
    const free = freeSlots(this.s);
    return slotAddr(free[Math.floor(this.rng() * free.length)]);
  }

  d(a: Addr): number {
    return this.s.nodes[a].dato;
  }

  push(line: string, title: string, message: string, extra: Partial<Frame> = {}) {
    this.frames.push({
      state: cloneState(this.s),
      vars: [...this.vars],
      line,
      title,
      message,
      order: [...this.order],
      raised: [...this.raised],
      garbage: [...this.garbage],
      visited: [...this.visited],
      changed: [],
      focus: [],
      nullSide: this.nullSide,
      method: this.method,
      ...extra,
    });
  }
}

/* ------------------------------------------------------------------ */
/*  Métodos                                                            */
/* ------------------------------------------------------------------ */

function agregarInicio(init: ListState, elemento: number, rng: () => number): Frame[] {
  const r = new Rec(init, 'agregarInicio', rng);
  r.set('elemento', int(elemento));
  r.push(
    'sig',
    'Se llama al método',
    `Se invoca \`agregarInicio(${elemento})\`. Java apila un **marco nuevo en el stack** para este método y guarda ahí el parámetro \`elemento = ${elemento}\`.`,
  );

  const a = r.alloc();
  r.s.nodes[a] = { addr: a, dato: elemento, anterior: null, siguiente: null };
  r.order = [a, ...r.order];
  r.raised = [a];
  r.set('nuevo', ref(a));
  r.push(
    'new',
    'new NodoDobleD(elemento)',
    `\`new\` reserva un objeto en el **heap**, en la dirección libre ${a}. El nodo nace con \`dato = ${elemento}\` y sus dos enlaces en \`null\`. La variable local \`nuevo\` (en el stack) solo guarda la **dirección** ${a}.`,
    { created: a, focus: [a], changed: ['var:nuevo'] },
  );

  const old = r.s.inicio;
  if (old === null) {
    r.push(
      'if',
      '¿Vacia()?',
      '`Vacia()` devuelve `inicio == null` → **true**. La lista no tiene nodos, así que se entra al bloque `if`.',
      { focus: [a] },
    );
    r.s.inicio = a;
    r.raised = [];
    r.push('i1', 'inicio = nuevo', `\`inicio\` copia la dirección ${a}: el nodo nuevo es el **primero**.`, {
      changed: ['inicio'],
      focus: [a],
    });
    r.s.fin = a;
    r.push(
      'f1',
      'fin = nuevo',
      `\`fin\` también guarda ${a}. Con un solo nodo, **inicio y fin apuntan al mismo objeto** y sus dos enlaces siguen en \`null\`.`,
      { changed: ['fin'], focus: [a] },
    );
  } else {
    r.push(
      'if',
      '¿Vacia()?',
      `\`Vacia()\` devuelve \`inicio == null\` → **false** (inicio vale ${old}). Se ejecuta el \`else\`.`,
      { focus: [old] },
    );
    r.s.nodes[a].siguiente = old;
    r.push(
      'a1',
      'nuevo.siguiente = inicio',
      `El campo \`siguiente\` del nodo nuevo copia la dirección que tiene \`inicio\` (${old}). Ahora el nuevo "ve" hacia adelante al que era el primero.`,
      { changed: [`${a}.siguiente`], focus: [a] },
    );
    r.s.nodes[old].anterior = a;
    r.push(
      'a2',
      'inicio.anterior = nuevo',
      `El que era el primero (${old}) guarda en su \`anterior\` la dirección ${a}. El enlace ya es **doble** ⇄: se puede ir y volver.`,
      { changed: [`${old}.anterior`], focus: [old] },
    );
    r.s.inicio = a;
    r.raised = [];
    r.push(
      'a3',
      'inicio = nuevo',
      `\`inicio\` se mueve a ${a}. El nodo nuevo es oficialmente el **primero**. (Si esta línea fuera la primera, ¡perderíamos la dirección del viejo primero!)`,
      { changed: ['inicio'], focus: [a] },
    );
  }
  r.vars = [];
  r.push(
    'end',
    'Fin del método',
    'El método termina y su marco del stack (`elemento`, `nuevo`) **desaparece**. El nodo NO se pierde porque `inicio` lo sigue referenciando. Costo: **O(1)**, sin importar cuántos nodos haya.',
    { done: true },
  );
  return r.frames;
}

function agregarFinal(init: ListState, elemento: number, rng: () => number): Frame[] {
  const r = new Rec(init, 'agregarFinal', rng);
  r.set('elemento', int(elemento));
  r.push(
    'sig',
    'Se llama al método',
    `Se invoca \`agregarFinal(${elemento})\`. Se crea un marco en el **stack** con el parámetro \`elemento = ${elemento}\`.`,
  );

  const a = r.alloc();
  r.s.nodes[a] = { addr: a, dato: elemento, anterior: null, siguiente: null };
  r.order = [...r.order, a];
  r.raised = [a];
  r.set('nuevo', ref(a));
  r.push(
    'new',
    'new NodoDobleD(elemento)',
    `Se reserva un nodo nuevo en el **heap** (${a}) con \`dato = ${elemento}\`, \`anterior = null\` y \`siguiente = null\`. La variable \`nuevo\` guarda su dirección.`,
    { created: a, focus: [a], changed: ['var:nuevo'] },
  );

  const oldFin = r.s.fin;
  if (r.s.inicio === null || oldFin === null) {
    r.push('if', '¿Vacia()?', '`Vacia()` → **true**: la lista está vacía, se entra al `if`.', { focus: [a] });
    r.s.inicio = a;
    r.raised = [];
    r.push('i1', 'inicio = nuevo', `\`inicio\` apunta al nuevo nodo (${a}).`, { changed: ['inicio'], focus: [a] });
    r.s.fin = a;
    r.push(
      'f1',
      'fin = nuevo',
      `\`fin\` también apunta a ${a}. Con un único nodo, **inicio == fin**.`,
      { changed: ['fin'], focus: [a] },
    );
  } else {
    r.push(
      'if',
      '¿Vacia()?',
      `\`Vacia()\` → **false**. Se va al \`else\`. Fíjate: no hace falta recorrer, porque \`fin\` ya señala al último (${oldFin}).`,
      { focus: [oldFin] },
    );
    r.s.nodes[oldFin].siguiente = a;
    r.push(
      'a1',
      'fin.siguiente = nuevo',
      `El último nodo actual (${oldFin}) cambia su \`siguiente\` de \`null\` a ${a}.`,
      { changed: [`${oldFin}.siguiente`], focus: [oldFin] },
    );
    r.s.nodes[a].anterior = oldFin;
    r.push(
      'a2',
      'nuevo.anterior = fin',
      `El nodo nuevo guarda en su \`anterior\` la dirección del que era el último (${oldFin}). Enlace doble listo ⇄.`,
      { changed: [`${a}.anterior`], focus: [a] },
    );
    r.s.fin = a;
    r.raised = [];
    r.push(
      'a3',
      'fin = nuevo',
      `\`fin\` se mueve a ${a}: el nuevo es el último. Gracias a tener \`fin\`, esto es **O(1)**.`,
      { changed: ['fin'], focus: [a] },
    );
  }
  r.vars = [];
  r.push(
    'end',
    'Fin del método',
    'Se destruye el marco del stack (`elemento`, `nuevo`). El nodo sigue vivo porque `fin` (y el `siguiente` del penúltimo) lo referencian.',
    { done: true },
  );
  return r.frames;
}

function eliminarExtremo(init: ListState, rng: () => number, fromStart: boolean): Frame[] {
  const method: MethodName = fromStart ? 'eliminarInicio' : 'eliminarFinal';
  const r = new Rec(init, method, rng);
  r.push(
    'sig',
    'Se llama al método',
    fromStart
      ? 'Se invoca `eliminarInicio()`. No recibe parámetros: siempre quita el **primer** nodo.'
      : 'Se invoca `eliminarFinal()`. No recibe parámetros: siempre quita el **último** nodo.',
  );

  const target = fromStart ? r.s.inicio : r.s.fin;
  if (target === null) {
    r.push('if', '¿Vacia()?', '`Vacia()` → **true**: no hay nada que eliminar.');
    r.push('err', 'JOptionPane de error', 'Se muestra un mensaje de **error** al usuario.', {
      dialog: { title: 'ERROR', message: 'La lista está vacía', type: 'error' },
    });
    r.push('ret', 'return', '`return` termina el método de inmediato. La lista queda igual (vacía).', {
      done: true,
    });
    return r.frames;
  }
  r.push('if', '¿Vacia()?', `\`Vacia()\` → **false** (inicio vale ${r.s.inicio}). Hay algo que eliminar.`, {
    focus: [target],
  });

  if (r.s.inicio === r.s.fin) {
    r.push(
      'one',
      '¿inicio == fin?',
      `**true**: \`inicio\` y \`fin\` guardan la misma dirección (${target}). Es el **único** nodo de la lista.`,
      { focus: [target] },
    );
    r.s.inicio = null;
    r.push(
      'n1',
      'inicio = null',
      '`inicio` deja de apuntar al nodo. Todavía no es basura: `fin` aún lo referencia.',
      { changed: ['inicio'], focus: [target] },
    );
    r.s.fin = null;
    r.garbage = [target];
    r.push(
      'n2',
      'fin = null',
      `\`fin\` también queda en \`null\`. Ahora **nadie** apunta al nodo ${target}: es **inalcanzable**. La lista vuelve a estar vacía.`,
      { changed: ['fin'] },
    );
  } else if (fromStart) {
    const second = r.s.nodes[target].siguiente as Addr;
    r.push(
      'one',
      '¿inicio == fin?',
      `**false**: hay varios nodos (inicio = ${r.s.inicio}, fin = ${r.s.fin}). Se va al \`else\`.`,
      { focus: [target] },
    );
    r.s.inicio = second;
    r.push(
      'a1',
      'inicio = inicio.siguiente',
      `\`inicio\` avanza al segundo nodo (${second}). Ojo: el nodo viejo (${target}) aún es alcanzable, porque el \`anterior\` del nuevo primero todavía lo apunta.`,
      { changed: ['inicio'], focus: [second] },
    );
    r.s.nodes[second].anterior = null;
    r.garbage = [target];
    r.push(
      'a2',
      'inicio.anterior = null',
      `Se corta el enlace hacia atrás. El nodo ${target} queda **inalcanzable**: su \`siguiente\` todavía apunta a ${second}, pero eso no importa porque **nadie llega a él**.`,
      { changed: [`${second}.anterior`], focus: [second] },
    );
  } else {
    const prev = r.s.nodes[target].anterior as Addr;
    r.push(
      'one',
      '¿inicio == fin?',
      `**false**: hay varios nodos (inicio = ${r.s.inicio}, fin = ${r.s.fin}). Se va al \`else\`.`,
      { focus: [target] },
    );
    r.s.fin = prev;
    r.push(
      'a1',
      'fin = fin.anterior',
      `\`fin\` retrocede al penúltimo (${prev}) usando el enlace \`anterior\`. **Esta es la gran ventaja de la lista doble**: en una lista simple habría que recorrer todo desde el inicio para hallar al penúltimo.`,
      { changed: ['fin'], focus: [prev] },
    );
    r.s.nodes[prev].siguiente = null;
    r.garbage = [target];
    r.push(
      'a2',
      'fin.siguiente = null',
      `El nuevo último ya no apunta al viejo. El nodo ${target} queda **inalcanzable** (su \`anterior\` aún apunta a ${prev}, pero nadie llega a él).`,
      { changed: [`${prev}.siguiente`], focus: [prev] },
    );
  }

  r.push('ok', 'JOptionPane de éxito', 'Se informa al usuario que se eliminó el nodo.', {
    dialog: {
      title: 'ÉXITO',
      message: fromStart ? 'Elemento eliminado del inicio' : 'Elemento eliminado del final',
      type: 'info',
    },
  });

  delete r.s.nodes[target];
  r.order = r.order.filter((x) => x !== target);
  r.garbage = [];
  r.push(
    'end',
    'Garbage Collector',
    `El método termina. El **Garbage Collector** de Java detecta que el objeto en ${target} es inalcanzable y **libera esa memoria** del heap. En Java no existe \`delete\`: basta con que nadie lo referencie. Costo: **O(1)**.`,
    { freed: [target], done: true },
  );
  return r.frames;
}

function buscarElemento(init: ListState, elemento: number, rng: () => number): Frame[] {
  const r = new Rec(init, 'buscarElemento', rng);
  r.set('elemento', int(elemento));
  r.push(
    'sig',
    'Se llama al método',
    `Se invoca \`buscarElemento(${elemento})\`. Se buscará el valor ${elemento} nodo por nodo, empezando por el inicio.`,
  );
  if (r.s.inicio === null) {
    r.push('if', '¿Vacia()?', '`Vacia()` → **true**: no hay dónde buscar.');
    r.push('err', 'JOptionPane de error', 'Se muestra el error al usuario.', {
      dialog: { title: 'ERROR', message: 'La lista está vacía', type: 'error' },
    });
    r.push('ret', 'return', '`return` termina el método.', { done: true });
    return r.frames;
  }
  r.push('if', '¿Vacia()?', '`Vacia()` → **false**. Comienza la búsqueda.');

  let cur: Addr | null = r.s.inicio;
  r.set('actual', ref(cur));
  r.push(
    'act',
    'actual = inicio',
    `Se crea la variable local \`actual\` con la misma dirección que \`inicio\` (${cur}). Es como un **dedo** que señala nodo por nodo. ¡No se copia ningún nodo, solo la dirección!`,
    { changed: ['var:actual'], focus: [cur] },
  );
  let pos = 1;
  r.set('posicion', int(pos));
  r.push('pos', 'posicion = 1', 'Contador de posición: el primer nodo es la posición **1** (no 0).', { focus: [cur] });
  r.set('encontrado', bool(false));
  r.push('enc', 'encontrado = false', 'Bandera que indica si ya se encontró el valor. Empieza en `false`.', {
    focus: [cur],
  });

  let found = false;
  for (;;) {
    if (cur === null) {
      r.push(
        'while',
        'while (actual != null)',
        '`actual` es **null**: ya se pasó del último nodo. El ciclo termina sin encontrarlo.',
      );
      break;
    }
    r.push('while', 'while (actual != null)', `\`actual\` vale ${cur} (no es null) → se entra al ciclo.`, {
      focus: [cur],
    });
    const d = r.d(cur);
    const ok = d === elemento;
    r.visited = [...r.visited, cur];
    r.push(
      'cmp',
      `¿${d} == ${elemento}?`,
      ok
        ? `\`actual.dato\` es ${d}, **igual** a ${elemento}. ¡Lo encontramos!`
        : `\`actual.dato\` es ${d}, distinto de ${elemento}. Hay que seguir avanzando.`,
      { focus: [cur], compare: { addr: cur, ok, text: `${d} == ${elemento}` } },
    );
    if (ok) {
      found = true;
      r.set('encontrado', bool(true));
      r.push('set', 'encontrado = true', 'Se marca la bandera `encontrado`.', { focus: [cur] });
      r.push(
        'brk',
        'break',
        '`break` rompe el ciclo inmediatamente: no se revisan los nodos restantes (se reporta la **primera** coincidencia).',
        { focus: [cur] },
      );
      break;
    }
    cur = r.s.nodes[cur].siguiente;
    r.set('actual', ref(cur));
    r.push(
      'adv',
      'actual = actual.siguiente',
      cur
        ? `\`actual\` salta al siguiente nodo leyendo el campo \`siguiente\`: ahora vale ${cur}.`
        : '`actual.siguiente` era **null** (era el último), así que `actual` ahora vale `null`.',
      { changed: ['var:actual'], focus: cur ? [cur] : [] },
    );
    pos++;
    r.set('posicion', int(pos));
    r.push('inc', 'posicion++', `\`posicion\` sube a ${pos}.`, { focus: cur ? [cur] : [] });
  }

  r.push(
    'res',
    'if (encontrado)',
    found ? '`encontrado` es **true** → se muestra el mensaje de éxito.' : '`encontrado` es **false** → se va al `else`.',
    { focus: found && cur ? [cur] : [] },
  );
  if (found) {
    r.push('found', 'JOptionPane: encontrado', `Se informa la posición: **${pos}**.`, {
      dialog: { title: 'ENCONTRADO', message: `Elemento ${elemento} encontrado en la posición ${pos}`, type: 'info' },
      focus: cur ? [cur] : [],
    });
  } else {
    r.push('nf', 'JOptionPane: no encontrado', `Se revisaron los ${r.visited.length} nodos sin hallarlo.`, {
      dialog: { title: 'NO ENCONTRADO', message: `Elemento ${elemento} NO encontrado en la lista`, type: 'warning' },
    });
  }
  r.vars = [];
  r.push(
    'end',
    'Fin del método',
    'Búsqueda **lineal**: en el peor caso revisa los **n** nodos → **O(n)**. La lista no se modificó; solo se leyó.',
    { done: true },
  );
  return r.frames;
}

/** Bucle de búsqueda compartido por insertarDespuesDe / insertarAntesDe. */
function searchRef(r: Rec, valorRef: number): Addr | null {
  let cur: Addr | null = r.s.inicio;
  r.set('actual', ref(cur));
  r.push(
    'act',
    'actual = inicio',
    `\`actual\` empieza en el primer nodo (${cur}) para buscar el valor de referencia ${valorRef}.`,
    { changed: ['var:actual'], focus: cur ? [cur] : [] },
  );
  r.set('hallado', bool(false));
  r.push('hal', 'hallado = false', 'Bandera para saber si se encontró la referencia.', { focus: cur ? [cur] : [] });
  for (;;) {
    if (cur === null) {
      r.push(
        'while',
        'while (actual != null)',
        '`actual` es **null**: se recorrió toda la lista y la referencia no apareció.',
      );
      return null;
    }
    r.push('while', 'while (actual != null)', `\`actual\` = ${cur}, no es null → se revisa este nodo.`, {
      focus: [cur],
    });
    const d = r.d(cur);
    const ok = d === valorRef;
    r.visited = [...r.visited, cur];
    r.push(
      'cmp',
      `¿${d} == ${valorRef}?`,
      ok ? `**Sí**: este nodo contiene ${valorRef}.` : `No: ${d} ≠ ${valorRef}. Se sigue buscando.`,
      { focus: [cur], compare: { addr: cur, ok, text: `${d} == ${valorRef}` } },
    );
    if (ok) {
      r.set('hallado', bool(true));
      r.push('set', 'hallado = true', 'Se marca que se halló la referencia.', { focus: [cur] });
      r.push(
        'brk',
        'break',
        `\`break\` sale del ciclo. \`actual\` se queda señalando al nodo ${cur}: ese es el **punto de inserción**.`,
        { focus: [cur] },
      );
      return cur;
    }
    cur = r.s.nodes[cur].siguiente;
    r.set('actual', ref(cur));
    r.push(
      'adv',
      'actual = actual.siguiente',
      cur ? `\`actual\` avanza al siguiente nodo (${cur}).` : '`actual.siguiente` era `null` → `actual` queda en `null`.',
      { changed: ['var:actual'], focus: cur ? [cur] : [] },
    );
  }
}

function insertar(
  init: ListState,
  valorRef: number,
  nuevoValor: number,
  rng: () => number,
  after: boolean,
): Frame[] {
  const method: MethodName = after ? 'insertarDespuesDe' : 'insertarAntesDe';
  const r = new Rec(init, method, rng);
  r.set('valorReferencia', int(valorRef));
  r.set('nuevoValor', int(nuevoValor));
  r.push(
    'sig',
    'Se llama al método',
    `Se invoca \`${method}(${valorRef}, ${nuevoValor})\`: insertar ${nuevoValor} **${after ? 'después' : 'antes'}** del nodo que contiene ${valorRef}.`,
  );
  if (r.s.inicio === null) {
    r.push('if', '¿Vacia()?', '`Vacia()` → **true**: no hay ningún nodo de referencia.');
    r.push('err', 'JOptionPane de advertencia', 'Se avisa que no se puede insertar.', {
      dialog: { title: 'LISTA VACÍA', message: 'La lista está vacía, imposible insertar.', type: 'warning' },
    });
    r.push('ret', 'return', '`return` termina el método.', { done: true });
    return r.frames;
  }
  r.push('if', '¿Vacia()?', '`Vacia()` → **false**. Primero hay que **encontrar** el nodo de referencia.');

  const target = searchRef(r, valorRef);
  r.push(
    'nh',
    'if (!hallado)',
    target
      ? '`hallado` es **true** → `!hallado` es false: se salta el bloque de error.'
      : '`hallado` es **false** → `!hallado` es true: hay que avisar.',
    { focus: target ? [target] : [] },
  );
  if (target === null) {
    r.push('nherr', 'JOptionPane: no encontrado', `El valor ${valorRef} no existe en la lista.`, {
      dialog: {
        title: 'NO ENCONTRADO',
        message: `El elemento de referencia ${valorRef} no se encuentra en la lista.`,
        type: 'warning',
      },
    });
    r.vars = [];
    r.push('nhret', 'return', '`return`: el método termina sin crear ningún nodo. La lista no cambia.', {
      done: true,
    });
    return r.frames;
  }

  const a = r.alloc();
  r.s.nodes[a] = { addr: a, dato: nuevoValor, anterior: null, siguiente: null };
  const idx = r.order.indexOf(target);
  r.order = after
    ? [...r.order.slice(0, idx + 1), a, ...r.order.slice(idx + 1)]
    : [...r.order.slice(0, idx), a, ...r.order.slice(idx)];
  r.raised = [a];
  r.visited = [];
  r.set('nuevo', ref(a));
  r.push(
    'new',
    'new NodoDobleD(nuevoValor)',
    `Se crea el nodo ${nuevoValor} en el heap (${a}), todavía **desconectado**: sus enlaces están en \`null\` y nadie lo conoce, salvo la variable \`nuevo\`.`,
    { created: a, focus: [a], changed: ['var:nuevo'] },
  );

  if (after) {
    if (target === r.s.fin) {
      r.push(
        'isfin',
        'if (actual == fin)',
        `**true**: ${valorRef} es el **último** nodo. Insertar después de él es como agregar al final.`,
        { focus: [target] },
      );
      r.s.nodes[target].siguiente = a;
      r.push('f1', 'actual.siguiente = nuevo', `El último nodo (${target}) cambia su \`siguiente\` de \`null\` a ${a}.`, {
        changed: [`${target}.siguiente`],
        focus: [target],
      });
      r.s.nodes[a].anterior = target;
      r.push('f2', 'nuevo.anterior = actual', `El nuevo nodo apunta hacia atrás a ${target}.`, {
        changed: [`${a}.anterior`],
        focus: [a],
      });
      r.s.fin = a;
      r.raised = [];
      r.push('f3', 'fin = nuevo', `\`fin\` se mueve al nuevo nodo (${a}), que ahora es el último.`, {
        changed: ['fin'],
        focus: [a],
      });
    } else {
      const nx = r.s.nodes[target].siguiente as Addr;
      r.push(
        'isfin',
        'if (actual == fin)',
        `**false**: ${valorRef} tiene un vecino a su derecha (${nx}). Caso general: hay que reconectar **4 enlaces**.`,
        { focus: [target] },
      );
      r.s.nodes[a].siguiente = nx;
      r.push(
        'g1',
        'nuevo.siguiente = actual.siguiente',
        `① El nuevo apunta hacia adelante al vecino derecho de \`actual\` (${nx}). La lista original todavía no cambia.`,
        { changed: [`${a}.siguiente`], focus: [a] },
      );
      r.s.nodes[a].anterior = target;
      r.push(
        'g2',
        'nuevo.anterior = actual',
        `② El nuevo apunta hacia atrás a \`actual\` (${target}). El nuevo ya conoce a sus dos vecinos… pero ellos aún no lo conocen a él.`,
        { changed: [`${a}.anterior`], focus: [a] },
      );
      r.s.nodes[nx].anterior = a;
      r.push(
        'g3',
        'actual.siguiente.anterior = nuevo',
        `③ El vecino derecho (${nx}) ahora apunta hacia atrás al nuevo. **Debe ir antes del ④**: todavía llegamos a ${nx} a través de \`actual.siguiente\`.`,
        { changed: [`${nx}.anterior`], focus: [nx] },
      );
      r.s.nodes[target].siguiente = a;
      r.raised = [];
      r.push(
        'g4',
        'actual.siguiente = nuevo',
        `④ Por último, \`actual\` apunta hacia adelante al nuevo. ¡Quedó insertado entre ${target} y ${nx}!`,
        { changed: [`${target}.siguiente`], focus: [a] },
      );
    }
  } else if (target === r.s.inicio) {
    r.push(
      'isini',
      'if (actual == inicio)',
      `**true**: ${valorRef} es el **primer** nodo. El nuevo pasará a ser el inicio (igual que en \`agregarInicio\`).`,
      { focus: [target] },
    );
    r.s.nodes[a].siguiente = target;
    r.push('i1', 'nuevo.siguiente = inicio', `El nuevo apunta hacia adelante al primer nodo actual (${target}).`, {
      changed: [`${a}.siguiente`],
      focus: [a],
    });
    r.s.nodes[target].anterior = a;
    r.push('i2', 'inicio.anterior = nuevo', `El primer nodo (${target}) cambia su \`anterior\` de \`null\` a ${a}.`, {
      changed: [`${target}.anterior`],
      focus: [target],
    });
    r.s.inicio = a;
    r.raised = [];
    r.push('i3', 'inicio = nuevo', '`inicio` se mueve al nuevo nodo. ¡Es el nuevo primero!', {
      changed: ['inicio'],
      focus: [a],
    });
  } else {
    const pv = r.s.nodes[target].anterior as Addr;
    r.push(
      'isini',
      'if (actual == inicio)',
      `**false**: ${valorRef} tiene un vecino a su izquierda (${pv}). Caso general: se reconectan **4 enlaces**.`,
      { focus: [target] },
    );
    r.s.nodes[a].anterior = pv;
    r.push(
      'g1',
      'nuevo.anterior = actual.anterior',
      `① El nuevo apunta hacia atrás al vecino izquierdo de \`actual\` (${pv}).`,
      { changed: [`${a}.anterior`], focus: [a] },
    );
    r.s.nodes[a].siguiente = target;
    r.push('g2', 'nuevo.siguiente = actual', `② El nuevo apunta hacia adelante a \`actual\` (${target}).`, {
      changed: [`${a}.siguiente`],
      focus: [a],
    });
    r.s.nodes[pv].siguiente = a;
    r.push(
      'g3',
      'actual.anterior.siguiente = nuevo',
      `③ El vecino izquierdo (${pv}) ahora apunta hacia adelante al nuevo. **Va antes del ④**: aún se llega a ${pv} mediante \`actual.anterior\`.`,
      { changed: [`${pv}.siguiente`], focus: [pv] },
    );
    r.s.nodes[target].anterior = a;
    r.raised = [];
    r.push(
      'g4',
      'actual.anterior = nuevo',
      `④ \`actual\` apunta hacia atrás al nuevo. ¡Quedó insertado entre ${pv} y ${target}!`,
      { changed: [`${target}.anterior`], focus: [a] },
    );
  }

  r.push('ok', 'JOptionPane: inserción exitosa', 'Se confirma la inserción al usuario.', {
    dialog: {
      title: 'INSERCIÓN EXITOSA',
      message: `Se insertó con éxito el valor ${nuevoValor} ${after ? 'después' : 'antes'} de ${valorRef}`,
      type: 'info',
    },
  });
  r.vars = [];
  r.push(
    'end',
    'Fin del método',
    'Costo: encontrar la referencia es **O(n)**, pero enlazar el nodo es **O(1)**: solo se tocaron unas pocas referencias y **ningún otro nodo se movió** en memoria.',
    { done: true },
  );
  return r.frames;
}

function mostrar(init: ListState, rng: () => number, reverse: boolean): Frame[] {
  const method: MethodName = reverse ? 'MostrarListaFinInicio' : 'MostrarListaInicioFin';
  const r = new Rec(init, method, rng);
  r.nullSide = reverse ? 'left' : 'right';
  const link = reverse ? 'anterior' : 'siguiente';
  r.push(
    'sig',
    'Se llama al método',
    reverse
      ? 'Se invoca `MostrarListaFinInicio()`: recorre **de atrás hacia adelante** usando los enlaces `anterior`. ¡Esto solo es posible porque la lista es **doble**!'
      : 'Se invoca `MostrarListaInicioFin()`: recorre de principio a fin usando los enlaces `siguiente`.',
  );
  let lista = 'null <-> ';
  r.set('lista', str(lista));
  r.push(
    'str',
    'String lista = "null <-> "',
    'Se crea el texto inicial. (Dato curioso: cada concatenación crea un **String nuevo** en el heap, porque los String son inmutables.)',
  );
  let cur = reverse ? r.s.fin : r.s.inicio;
  r.set('actual', ref(cur));
  r.push(
    'act',
    reverse ? 'actual = fin' : 'actual = inicio',
    cur
      ? `\`actual\` empieza en ${reverse ? 'el último' : 'el primer'} nodo (${cur}).`
      : 'La lista está vacía: `actual` empieza valiendo `null`.',
    { changed: ['var:actual'], focus: cur ? [cur] : [] },
  );
  for (;;) {
    if (cur === null) {
      r.push('while', 'while (actual != null)', '`actual` es **null** → termina el recorrido.');
      break;
    }
    r.push('while', 'while (actual != null)', `\`actual\` = ${cur} → se procesa este nodo.`, { focus: [cur] });
    const d = r.d(cur);
    lista = lista + d + ' <-> ';
    r.set('lista', str(lista));
    r.visited = [...r.visited, cur];
    r.push('cat', `lista += ${d}`, `Se lee \`actual.dato\` (${d}) y se pega al texto.`, { focus: [cur] });
    cur = reverse ? r.s.nodes[cur].anterior : r.s.nodes[cur].siguiente;
    r.set('actual', ref(cur));
    r.push(
      'adv',
      `actual = actual.${link}`,
      cur
        ? `\`actual\` ${reverse ? 'retrocede' : 'avanza'} a ${cur} usando el enlace \`${link}\`.`
        : `El enlace \`${link}\` era \`null\`: \`actual\` queda en \`null\`.`,
      { changed: ['var:actual'], focus: cur ? [cur] : [] },
    );
  }
  lista = lista + 'null';
  r.set('lista', str(lista));
  r.push('null', 'lista += "null"', 'Se cierra el texto con `"null"`, que representa el final de la cadena.');
  r.push('show', 'JOptionPane con el resultado', `Se muestra: \`${lista}\``, {
    dialog: { title: reverse ? 'Lista de Fin a Inicio' : 'Lista de Inicio a Fin', message: lista, type: 'info' },
  });
  r.vars = [];
  r.push(
    'end',
    'Fin del método',
    `Recorrido completo: visitó ${r.visited.length} nodo(s) → **O(n)**. La lista no cambió.`,
    { done: true },
  );
  return r.frames;
}

export function runOperation(init: ListState, op: Operation, rng: () => number = Math.random): Frame[] {
  switch (op.method) {
    case 'agregarInicio':
      return agregarInicio(init, op.value, rng);
    case 'agregarFinal':
      return agregarFinal(init, op.value, rng);
    case 'buscarElemento':
      return buscarElemento(init, op.value, rng);
    case 'eliminarInicio':
      return eliminarExtremo(init, rng, true);
    case 'eliminarFinal':
      return eliminarExtremo(init, rng, false);
    case 'insertarDespuesDe':
      return insertar(init, op.ref, op.value, rng, true);
    case 'insertarAntesDe':
      return insertar(init, op.ref, op.value, rng, false);
    case 'MostrarListaInicioFin':
      return mostrar(init, rng, false);
    case 'MostrarListaFinInicio':
      return mostrar(init, rng, true);
  }
}
