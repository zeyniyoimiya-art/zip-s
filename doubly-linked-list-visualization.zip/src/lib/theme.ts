export const COLORS = {
  /** enlace siguiente → */
  sig: '#34d399',
  /** enlace ← anterior */
  ant: '#fb923c',
  /** inicio / fin */
  ptr: '#a78bfa',
  /** variables locales (nuevo, actual) */
  var: '#fbbf24',
  /** lo que acaba de cambiar */
  hl: '#facc15',
  focus: '#fde047',
  garbage: '#f87171',
  list: '#c4b5fd',
};
