import { Database, Layers, Recycle, Sparkles, Trash2 } from 'lucide-react';
import { useId, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import {
  HEAP_SLOTS,
  LIST_ADDR,
  LIST_SLOT,
  OTHER_SLOTS,
  slotAddr,
  slotOf,
  type Frame,
  type NodeData,
  type VarValue,
} from '../lib/engine';
import { COLORS } from '../lib/theme';
import { cn } from '../utils/cn';
import { AddrText, addrColor } from './common';

type Kind = 'sig' | 'ant' | 'ptr' | 'var';
interface R {
  x: number;
  y: number;
  w: number;
  h: number;
}
interface MemArrow {
  id: string;
  d: string;
  kind: Kind;
  owner: string;
  to: string;
}

const KIND_COLOR: Record<Kind, string> = {
  sig: COLORS.sig,
  ant: COLORS.ant,
  ptr: COLORS.ptr,
  var: COLORS.var,
};

function memPath(s: R, t: R): string | null {
  const scx = s.x + s.w / 2;
  const scy = s.y + s.h / 2;
  if (scx > t.x && scx < t.x + t.w && scy > t.y && scy < t.y + t.h) return null;
  const tcx = t.x + t.w / 2;
  const sx = tcx >= scx ? s.x + s.w : s.x;
  const sy = scy;
  const cands = [
    { x: t.x, y: t.y + t.h / 2 },
    { x: t.x + t.w, y: t.y + t.h / 2 },
    { x: t.x + t.w / 2, y: t.y },
    { x: t.x + t.w / 2, y: t.y + t.h },
  ];
  let best = cands[0];
  let bd = Infinity;
  for (const c of cands) {
    const dd = (c.x - sx) ** 2 + (c.y - sy) ** 2;
    if (dd < bd) {
      bd = dd;
      best = c;
    }
  }
  const dx = best.x - sx;
  const dy = best.y - sy;
  const len = Math.hypot(dx, dy) || 1;
  const off = Math.min(70, len * 0.28);
  const qx = (sx + best.x) / 2 - (dy / len) * off;
  const qy = (sy + best.y) / 2 + (dx / len) * off;
  return `M ${sx} ${sy} Q ${qx} ${qy} ${best.x} ${best.y}`;
}

export function varType(v: VarValue): string {
  if (v.kind === 'ref') return 'NodoDobleD';
  if (v.kind === 'int') return 'int';
  if (v.kind === 'bool') return 'boolean';
  return 'String';
}

export function VarValueView({ v }: { v: VarValue }) {
  if (v.kind === 'ref') return <AddrText addr={v.value} />;
  if (v.kind === 'int') return <span className="font-mono font-bold text-fuchsia-300">{v.value}</span>;
  if (v.kind === 'bool') return <span className="font-mono font-bold text-pink-400">{String(v.value)}</span>;
  return (
    <span className="block max-w-[240px] truncate font-mono text-lime-300" title={`"${v.value}"`}>
      "{v.value}"
    </span>
  );
}

function FieldRow({
  label,
  children,
  from,
  to,
  kind,
  owner,
  changed,
}: {
  label: string;
  children: ReactNode;
  from?: string;
  to?: string | null;
  kind?: Kind;
  owner?: string;
  changed?: boolean;
}) {
  return (
    <div
      data-from={to ? from : undefined}
      data-to={to ?? undefined}
      data-kind={kind}
      data-owner={owner}
      className={cn(
        'flex items-center justify-between gap-1 rounded px-1.5 py-[3px] font-mono text-[10.5px] leading-tight',
        changed && 'flash-bg ring-1 ring-yellow-400/70',
      )}
    >
      <span
        className={cn(
          'text-slate-400',
          kind === 'sig' && 'text-emerald-300/90',
          kind === 'ant' && 'text-orange-300/90',
          kind === 'ptr' && 'text-violet-300',
        )}
      >
        {label}
      </span>
      <span className="truncate">{children}</span>
    </div>
  );
}

interface Props {
  frame: Frame;
  hovered?: string | null;
  onHover?: (a: string | null) => void;
  showArrows?: boolean;
  className?: string;
}

export function MemoryView({ frame, hovered = null, onHover, showArrows = true, className }: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const boxRef = useRef<HTMLDivElement>(null);
  const [arrows, setArrows] = useState<MemArrow[]>([]);
  const [size, setSize] = useState({ w: 0, h: 0 });

  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    let raf = 0;
    const measure = () => {
      const b = box.getBoundingClientRect();
      const rel = (r: DOMRect): R => ({ x: r.left - b.left, y: r.top - b.top, w: r.width, h: r.height });
      const cards = new Map<string, R>();
      box.querySelectorAll<HTMLElement>('[data-card]').forEach((el) => {
        cards.set(el.dataset.card as string, rel(el.getBoundingClientRect()));
      });
      const out: MemArrow[] = [];
      box.querySelectorAll<HTMLElement>('[data-from]').forEach((el) => {
        const to = el.dataset.to;
        if (!to) return;
        const t = cards.get(to);
        if (!t) return;
        const d = memPath(rel(el.getBoundingClientRect()), t);
        if (!d) return;
        out.push({
          id: el.dataset.from as string,
          d,
          kind: (el.dataset.kind as Kind) ?? 'ptr',
          owner: el.dataset.owner ?? '',
          to,
        });
      });
      setArrows(out);
      setSize({ w: b.width, h: b.height });
    };
    const schedule = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(measure);
    };
    measure();
    const ro = new ResizeObserver(schedule);
    ro.observe(box);
    document.fonts?.ready.then(schedule).catch(() => undefined);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [frame, showArrows]);

  const bySlot: Record<number, NodeData> = {};
  for (const nd of Object.values(frame.state.nodes)) bySlot[slotOf(nd.addr)] = nd;
  const methodActive = !!frame.method && !frame.done;
  const ch = (k: string) => frame.changed.includes(k);

  return (
    <div ref={boxRef} className={cn('relative', className)}>
      {/* ---------------- STACK ---------------- */}
      <div className="mb-4 rounded-xl border border-amber-500/20 bg-amber-950/10 p-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-300">
            <Layers size={14} /> Stack <span className="font-normal normal-case tracking-normal text-slate-500">· pila de llamadas (variables locales)</span>
          </div>
        </div>
        <div className="flex flex-col-reverse gap-2 md:flex-row md:items-stretch">
          <div className="min-w-[200px] flex-1 rounded-lg border border-slate-700/70 bg-slate-900/80 p-2 md:max-w-[260px]">
            <div className="mb-1 font-mono text-[11px] font-bold text-sky-300">main(String[] args)</div>
            <FieldRow label="ListaMetodoDoble lista" from="main:lista" to={LIST_ADDR} kind="ptr" owner="stack">
              <AddrText addr={LIST_ADDR} />
            </FieldRow>
          </div>
          {methodActive ? (
            <div className="min-w-0 flex-[2] rounded-lg border border-amber-400/50 bg-amber-500/[0.06] p-2 shadow-[0_0_24px_-8px_rgba(251,191,36,0.5)]">
              <div className="mb-1 flex items-center justify-between font-mono text-[11px] font-bold text-amber-300">
                <span>{frame.method}(…)</span>
                <span className="rounded bg-amber-400/20 px-1.5 text-[9px] uppercase tracking-wider">en ejecución</span>
              </div>
              <div className="grid gap-x-3 sm:grid-cols-2">
                <FieldRow label="this">
                  <AddrText addr={LIST_ADDR} />
                </FieldRow>
                {frame.vars.map(([name, v]) => (
                  <FieldRow
                    key={name}
                    label={`${varType(v)} ${name}`}
                    from={`var:${name}`}
                    to={v.kind === 'ref' ? v.value : null}
                    kind="var"
                    owner="stack"
                    changed={ch(`var:${name}`)}
                  >
                    <VarValueView v={v} />
                  </FieldRow>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-[2] items-center justify-center rounded-lg border border-dashed border-slate-700/70 p-2 text-center text-[11px] text-slate-500">
              Ningún método en ejecución: sus variables locales ya se destruyeron.
            </div>
          )}
        </div>
      </div>

      {/* ---------------- HEAP ---------------- */}
      <div className="rounded-xl border border-sky-500/20 bg-sky-950/10 p-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-300">
            <Database size={14} /> Heap{' '}
            <span className="font-normal normal-case tracking-normal text-slate-500">
              · memoria de objetos (cada celda = 24 bytes, direcciones ilustrativas)
            </span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
          {Array.from({ length: HEAP_SLOTS }, (_, i) => {
            const addr = slotAddr(i);
            if (i === LIST_SLOT) {
              return (
                <div
                  key={i}
                  data-card={addr}
                  className="rounded-lg border border-violet-500/60 bg-violet-950/40 p-1.5 shadow-[0_0_20px_-8px_rgba(167,139,250,0.7)]"
                >
                  <div className="flex items-center justify-between px-1.5 font-mono text-[10px]">
                    <AddrText addr={addr} />
                  </div>
                  <div className="px-1.5 pb-1 font-mono text-[10px] font-bold text-violet-200">ListaMetodoDoble</div>
                  <FieldRow label="inicio" from="inicio" to={frame.state.inicio} kind="ptr" owner={LIST_ADDR} changed={ch('inicio')}>
                    <AddrText addr={frame.state.inicio} />
                  </FieldRow>
                  <FieldRow label="fin" from="fin" to={frame.state.fin} kind="ptr" owner={LIST_ADDR} changed={ch('fin')}>
                    <AddrText addr={frame.state.fin} />
                  </FieldRow>
                </div>
              );
            }
            if (OTHER_SLOTS[i]) {
              return (
                <div
                  key={i}
                  className="flex min-h-[104px] flex-col rounded-lg border border-slate-700/50 bg-[repeating-linear-gradient(135deg,rgba(51,65,85,0.25)_0_6px,transparent_6px_12px)] p-1.5"
                >
                  <span className="px-1.5 font-mono text-[10px] text-slate-500">{addr}</span>
                  <span className="m-auto text-center text-[10px] leading-tight text-slate-500">
                    otro objeto
                    <br />
                    <span className="font-mono text-slate-400">({OTHER_SLOTS[i]})</span>
                  </span>
                </div>
              );
            }
            const nd = bySlot[i];
            if (nd) {
              const garbage = frame.garbage.includes(addr);
              const created = frame.created === addr;
              const focus = frame.focus.includes(addr);
              const hov = hovered === addr;
              return (
                <div
                  key={i}
                  data-card={addr}
                  onMouseEnter={() => onHover?.(addr)}
                  onMouseLeave={() => onHover?.(null)}
                  className={cn(
                    'relative rounded-lg border bg-slate-900/90 p-1.5 transition-[box-shadow,opacity,border-color] duration-300',
                    garbage ? 'border-dashed border-red-400/80 opacity-60' : 'border-slate-600/70',
                    focus && !garbage && 'ring-2 ring-yellow-300/80',
                    hov && 'ring-2 ring-sky-400',
                    created && 'shadow-[0_0_26px_-4px_rgba(250,204,21,0.8)]',
                  )}
                  style={{ borderTop: garbage ? undefined : `3px solid ${addrColor(addr)}` }}
                >
                  <div className="flex items-center justify-between px-1.5 font-mono text-[10px]">
                    <AddrText addr={addr} />
                    {created && (
                      <span className="flex items-center gap-0.5 rounded bg-yellow-400/20 px-1 text-[9px] font-bold text-yellow-300">
                        <Sparkles size={9} /> new
                      </span>
                    )}
                    {garbage && (
                      <span className="flex items-center gap-0.5 rounded bg-red-500/20 px-1 text-[9px] font-bold text-red-300">
                        <Trash2 size={9} /> GC
                      </span>
                    )}
                  </div>
                  <div className="px-1.5 pb-0.5 font-mono text-[10px] font-semibold text-cyan-300/90">NodoDobleD</div>
                  <FieldRow label="dato">
                    <span className="font-bold text-white">{nd.dato}</span>
                  </FieldRow>
                  <FieldRow
                    label="anterior"
                    from={`${addr}.anterior`}
                    to={nd.anterior}
                    kind="ant"
                    owner={addr}
                    changed={ch(`${addr}.anterior`)}
                  >
                    <AddrText addr={nd.anterior} />
                  </FieldRow>
                  <FieldRow
                    label="siguiente"
                    from={`${addr}.siguiente`}
                    to={nd.siguiente}
                    kind="sig"
                    owner={addr}
                    changed={ch(`${addr}.siguiente`)}
                  >
                    <AddrText addr={nd.siguiente} />
                  </FieldRow>
                </div>
              );
            }
            const freed = frame.freed?.includes(addr);
            return (
              <div
                key={i}
                className={cn(
                  'flex min-h-[104px] flex-col rounded-lg border border-dashed p-1.5',
                  freed ? 'border-emerald-400/60 bg-emerald-500/5' : 'border-slate-800',
                )}
              >
                <span className="px-1.5 font-mono text-[10px] text-slate-600">{addr}</span>
                {freed ? (
                  <span className="m-auto flex flex-col items-center gap-1 text-center text-[10px] font-semibold text-emerald-300">
                    <Recycle size={16} /> liberado por el GC
                  </span>
                ) : (
                  <span className="m-auto text-[10px] text-slate-700">libre</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ---------------- FLECHAS ---------------- */}
      {showArrows && size.w > 0 && (
        <svg
          className="pointer-events-none absolute left-0 top-0 z-20"
          width={size.w}
          height={size.h}
          style={{ overflow: 'visible' }}
        >
          <defs>
            {(Object.keys(KIND_COLOR) as Kind[]).map((k) => (
              <marker
                key={k}
                id={`mem-${k}-${uid}`}
                viewBox="0 0 10 10"
                refX="9"
                refY="5"
                markerWidth="8"
                markerHeight="8"
                markerUnits="userSpaceOnUse"
                orient="auto"
              >
                <path d="M0,0 L10,5 L0,10 z" fill={KIND_COLOR[k]} />
              </marker>
            ))}
            <marker id={`mem-hl-${uid}`} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="10" markerHeight="10" markerUnits="userSpaceOnUse" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill={COLORS.hl} />
            </marker>
          </defs>
          {arrows.map((a) => {
            const changed = ch(a.id);
            const related = hovered ? a.owner === hovered || a.to === hovered : true;
            return (
              <path
                key={a.id}
                d={a.d}
                fill="none"
                stroke={changed ? COLORS.hl : KIND_COLOR[a.kind]}
                strokeWidth={changed ? 2.8 : 1.6}
                strokeDasharray={a.kind === 'var' || a.id === 'main:lista' ? '5 4' : undefined}
                opacity={related ? (changed ? 1 : 0.72) : 0.07}
                markerEnd={`url(#mem-${changed ? 'hl' : a.kind}-${uid})`}
                style={{ transition: 'opacity 0.25s' }}
              />
            );
          })}
        </svg>
      )}
    </div>
  );
}
