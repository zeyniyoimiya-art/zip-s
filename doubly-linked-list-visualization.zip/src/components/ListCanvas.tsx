import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useId, useMemo, useRef } from 'react';
import { nodeColor, type Addr, type Frame } from '../lib/engine';
import { COLORS } from '../lib/theme';
import { cn } from '../utils/cn';

const NODE_W = 150;
const NODE_H = 62;
const CELL = 42;
const GAP = 66;
const PAD_X = 102;
const SLOT = NODE_W + GAP;
const LABEL_Y = 24;
const RAISED_Y = 68;
const MAIN_Y = 162;
const GARBAGE_Y = 254;
const VAR_Y = 358;
const H = 386;
const SIG_DY = 22;
const ANT_DY = 41;
const EASE: [number, number, number, number] = [0.4, 0, 0.2, 1];
const T = { duration: 0.6, ease: EASE };
const HL_FILL = 'rgba(250, 204, 21, 0.34)';

type P = { x: number; y: number };

/** Curva para un puntero. dir = 1 apunta a la derecha (siguiente), -1 a la izquierda (anterior). */
function pointerCurve(sx: number, sy: number, tx: number, ty: number, dir: 1 | -1): string {
  const forward = (tx - sx) * dir;
  if (forward > 8) {
    const k = Math.min(forward * 0.5, 90);
    return `M ${sx} ${sy} C ${sx + dir * k} ${sy} ${tx - dir * k} ${ty} ${tx} ${ty}`;
  }
  const loop = 95;
  const v = dir === 1 ? 1 : -1;
  return `M ${sx} ${sy} C ${sx + dir * loop} ${sy + v * loop} ${tx - dir * loop} ${ty + v * loop} ${tx} ${ty}`;
}

function vPath(x1: number, y1: number, x2: number, y2: number): string {
  const m = (y2 - y1) * 0.45;
  return `M ${x1} ${y1} C ${x1} ${y1 + m} ${x2} ${y2 - m} ${x2} ${y2}`;
}

const pillW = (text: string) => text.length * 7.6 + 22;

interface Props {
  frame: Frame;
  hovered?: string | null;
  onHover?: (a: string | null) => void;
  minSlots?: number;
  maxScale?: number;
  minScale?: number;
  className?: string;
  /** recorta la zona inferior (para diagramas estáticos sin variables) */
  compact?: boolean;
}

export function ListCanvas({
  frame,
  hovered = null,
  onHover,
  minSlots = 4,
  maxScale = 1.05,
  minScale = 0.6,
  className,
  compact = false,
}: Props) {
  const HH = compact ? MAIN_Y + NODE_H + 30 : H;
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const scrollRef = useRef<HTMLDivElement>(null);
  const n = frame.order.length;
  const W = PAD_X * 2 + Math.max(n, minSlots) * SLOT - GAP;
  const used = n > 0 ? PAD_X * 2 + n * SLOT - GAP : 0;
  const offX = n > 0 ? (W - used) / 2 : 0;
  const firstX = offX + PAD_X;
  const lastRight = offX + PAD_X + n * SLOT - GAP;

  const pos = useMemo(() => {
    const m: Record<Addr, P> = {};
    frame.order.forEach((a, i) => {
      const y = frame.raised.includes(a) ? RAISED_Y : frame.garbage.includes(a) ? GARBAGE_Y : MAIN_Y;
      m[a] = { x: firstX + i * SLOT, y };
    });
    return m;
  }, [frame, firstX]);

  const cx = (a: Addr) => pos[a].x + NODE_W / 2;
  const { nodes, inicio, fin } = frame.state;

  /* ---------- flechas entre nodos ---------- */
  const arrows: { key: string; d: string; kind: 'sig' | 'ant'; changed: boolean; dim: boolean }[] = [];
  for (const a of frame.order) {
    const nd = nodes[a];
    const p = pos[a];
    if (!nd || !p) continue;
    if (nd.siguiente && pos[nd.siguiente]) {
      const t = pos[nd.siguiente];
      arrows.push({
        key: `${a}-sig`,
        d: pointerCurve(p.x + NODE_W - CELL / 2, p.y + SIG_DY, t.x, t.y + SIG_DY, 1),
        kind: 'sig',
        changed: frame.changed.includes(`${a}.siguiente`),
        dim: !!hovered && hovered !== a && hovered !== nd.siguiente,
      });
    }
    if (nd.anterior && pos[nd.anterior]) {
      const t = pos[nd.anterior];
      arrows.push({
        key: `${a}-ant`,
        d: pointerCurve(p.x + CELL / 2, p.y + ANT_DY, t.x + NODE_W, t.y + ANT_DY, -1),
        kind: 'ant',
        changed: frame.changed.includes(`${a}.anterior`),
        dim: !!hovered && hovered !== a && hovered !== nd.anterior,
      });
    }
  }

  /* ---------- inicio / fin ---------- */
  const ini = inicio && pos[inicio] ? inicio : null;
  const fi = fin && pos[fin] ? fin : null;
  const same = !!ini && ini === fi;
  const labels = [
    {
      key: 'inicio',
      target: ini,
      x: ini ? cx(ini) - (same ? 36 : 0) : n ? firstX - 62 : W / 2 - 72,
      changed: frame.changed.includes('inicio'),
    },
    {
      key: 'fin',
      target: fi,
      x: fi ? cx(fi) + (same ? 36 : 0) : n ? lastRight + 62 : W / 2 + 72,
      changed: frame.changed.includes('fin'),
    },
  ];

  /* ---------- variables locales tipo referencia ---------- */
  const refVars = frame.vars
    .filter(([, v]) => v.kind === 'ref')
    .map(([name, v]) => ({ name, value: v.kind === 'ref' ? v.value : null }));
  const groups: Record<string, string[]> = {};
  for (const rv of refVars) {
    const k = rv.value && pos[rv.value] ? rv.value : 'null';
    (groups[k] ??= []).push(rv.name);
  }
  const vars = refVars.map((rv) => {
    const target = rv.value && pos[rv.value] ? rv.value : null;
    const g = groups[target ?? 'null'];
    const i = g.indexOf(rv.name);
    const off = (i - (g.length - 1) / 2) * 92;
    let x: number;
    if (target) x = cx(target) + off;
    else if (n === 0) x = W / 2 + off;
    else x = (frame.nullSide === 'left' ? firstX - 64 : lastRight + 64) + off;
    return { ...rv, target, x, off, changed: frame.changed.includes(`var:${rv.name}`) };
  });

  /* ---------- ¿quién apunta a cada nodo? ---------- */
  const incoming = new Set<Addr>();
  for (const nd of Object.values(nodes)) {
    if (nd.siguiente && nd.siguiente !== nd.addr) incoming.add(nd.siguiente);
    if (nd.anterior && nd.anterior !== nd.addr) incoming.add(nd.anterior);
  }
  if (inicio) incoming.add(inicio);
  if (fin) incoming.add(fin);

  /* ---------- auto-scroll al nodo en foco ---------- */
  useEffect(() => {
    const box = scrollRef.current;
    if (!box || box.scrollWidth <= box.clientWidth + 4) return;
    const target = frame.focus[0] ?? frame.created;
    if (!target || !pos[target]) return;
    const svg = box.querySelector('svg');
    if (!svg) return;
    const scale = svg.clientWidth / W;
    const x = (pos[target].x + NODE_W / 2) * scale;
    if (x < box.scrollLeft + 80 || x > box.scrollLeft + box.clientWidth - 80) {
      box.scrollTo({ left: x - box.clientWidth / 2, behavior: 'smooth' });
    }
  }, [frame, pos, W]);

  const mk = (k: string) => `url(#m-${k}-${uid})`;

  return (
    <div ref={scrollRef} className={cn('scroll-thin overflow-x-auto', className)}>
      <svg
        viewBox={`0 0 ${W} ${HH}`}
        role="img"
        aria-label="Diagrama de la lista doblemente enlazada"
        style={{
          width: '100%',
          minWidth: W * minScale,
          maxWidth: W * maxScale,
          height: 'auto',
          display: 'block',
          margin: '0 auto',
          fontFamily: '"JetBrains Mono", ui-monospace, monospace',
        }}
      >
        <defs>
          {(
            [
              ['sig', COLORS.sig],
              ['ant', COLORS.ant],
              ['ptr', COLORS.ptr],
              ['var', COLORS.var],
              ['hl', COLORS.hl],
            ] as const
          ).map(([k, c]) => (
            <marker
              key={k}
              id={`m-${k}-${uid}`}
              viewBox="0 0 10 10"
              refX="8.6"
              refY="5"
              markerWidth="10"
              markerHeight="10"
              markerUnits="userSpaceOnUse"
              orient="auto"
            >
              <path d="M0,0 L10,5 L0,10 z" fill={c} />
            </marker>
          ))}
          <filter id={`glow-${uid}`} filterUnits="userSpaceOnUse" x={-200} y={-200} width={W + 400} height={H + 400}>
            <feGaussianBlur stdDeviation="3.2" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <clipPath id={`clip-${uid}`}>
            <rect width={NODE_W} height={NODE_H} rx={11} />
          </clipPath>
        </defs>

        {/* lista vacía */}
        <AnimatePresence>
          {n === 0 && (
            <motion.g key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <rect
                x={W / 2 - 170}
                y={MAIN_Y - 6}
                width={340}
                height={NODE_H + 12}
                rx={14}
                fill="none"
                stroke="#334155"
                strokeDasharray="6 6"
              />
              <text x={W / 2} y={MAIN_Y + 28} textAnchor="middle" fontSize={16} fill="#64748b" fontWeight={700}>
                lista vacía
              </text>
              <text x={W / 2} y={MAIN_Y + 48} textAnchor="middle" fontSize={11} fill="#475569">
                Vacia() == true
              </text>
            </motion.g>
          )}
        </AnimatePresence>

        {/* nodos */}
        <AnimatePresence>
          {frame.order.map((a) => {
            const nd = nodes[a];
            const p = pos[a];
            if (!nd || !p) return null;
            const isFocus = frame.focus.includes(a);
            const isGarbage = frame.garbage.includes(a);
            const isRaised = frame.raised.includes(a);
            const isHover = hovered === a;
            const sigCh = frame.changed.includes(`${a}.siguiente`);
            const antCh = frame.changed.includes(`${a}.anterior`);
            const color = nodeColor(a);
            const visit = frame.visited.indexOf(a);
            return (
              <motion.g
                key={a}
                initial={{ opacity: 0, x: p.x, y: p.y - 46 }}
                animate={{ opacity: isGarbage ? 0.6 : 1, x: p.x, y: p.y }}
                exit={{ opacity: 0, y: p.y + 70, transition: { duration: 0.55 } }}
                transition={T}
                onMouseEnter={() => onHover?.(a)}
                onMouseLeave={() => onHover?.(null)}
              >
                {isFocus && (
                  <rect
                    x={-7}
                    y={-7}
                    width={NODE_W + 14}
                    height={NODE_H + 14}
                    rx={16}
                    fill="rgba(253,224,71,0.06)"
                    stroke={COLORS.focus}
                    strokeWidth={2}
                    filter={`url(#glow-${uid})`}
                  />
                )}
                <g clipPath={`url(#clip-${uid})`}>
                  <rect width={NODE_W} height={NODE_H} fill="#0b1224" />
                  <rect width={CELL} height={NODE_H} fill={antCh ? HL_FILL : 'rgba(251,146,60,0.10)'} />
                  <rect x={NODE_W - CELL} width={CELL} height={NODE_H} fill={sigCh ? HL_FILL : 'rgba(52,211,153,0.10)'} />
                  <rect x={CELL} width={NODE_W - CELL * 2} height={4} fill={color} />
                </g>
                <rect
                  width={NODE_W}
                  height={NODE_H}
                  rx={11}
                  fill="none"
                  stroke={isGarbage ? COLORS.garbage : isHover ? '#38bdf8' : '#3b4a63'}
                  strokeWidth={isHover || isGarbage ? 2.2 : 1.6}
                  strokeDasharray={isGarbage ? '7 5' : undefined}
                />
                <line x1={CELL} y1={0} x2={CELL} y2={NODE_H} stroke="#3b4a63" />
                <line x1={NODE_W - CELL} y1={0} x2={NODE_W - CELL} y2={NODE_H} stroke="#3b4a63" />
                <text x={CELL / 2} y={14} textAnchor="middle" fontSize={9} fill="#fdba74" opacity={0.85}>
                  ant
                </text>
                <text x={NODE_W - CELL / 2} y={NODE_H - 7} textAnchor="middle" fontSize={9} fill="#6ee7b7" opacity={0.85}>
                  sig
                </text>
                <text
                  x={NODE_W / 2}
                  y={35}
                  textAnchor="middle"
                  fontSize={String(nd.dato).length > 3 ? 17 : 23}
                  fontWeight={800}
                  fill="#f8fafc"
                >
                  {nd.dato}
                </text>
                <text x={NODE_W / 2} y={53} textAnchor="middle" fontSize={9.5} fill={color} fontWeight={600}>
                  {a}
                </text>
                {nd.anterior === null ? (
                  <text x={CELL / 2} y={ANT_DY + 4} textAnchor="middle" fontSize={10} fill="#64748b">
                    null
                  </text>
                ) : (
                  <circle cx={CELL / 2} cy={ANT_DY} r={4} fill={antCh ? COLORS.hl : COLORS.ant} />
                )}
                {nd.siguiente === null ? (
                  <text x={NODE_W - CELL / 2} y={SIG_DY + 4} textAnchor="middle" fontSize={10} fill="#64748b">
                    null
                  </text>
                ) : (
                  <circle cx={NODE_W - CELL / 2} cy={SIG_DY} r={4} fill={sigCh ? COLORS.hl : COLORS.sig} />
                )}
                {visit >= 0 && (
                  <g>
                    <circle cx={-3} cy={-3} r={10} fill="#0284c7" stroke="#0b1224" strokeWidth={2} />
                    <text x={-3} y={1} textAnchor="middle" fontSize={10} fontWeight={800} fill="#fff">
                      {visit + 1}
                    </text>
                  </g>
                )}
                {isRaised && !incoming.has(a) && (
                  <text x={NODE_W / 2} y={-9} textAnchor="middle" fontSize={10} fill="#fbbf24">
                    recién creado · nadie lo apunta aún
                  </text>
                )}
                {isGarbage && (
                  <text x={NODE_W / 2} y={NODE_H + 17} textAnchor="middle" fontSize={10.5} fill={COLORS.garbage} fontWeight={700}>
                    inalcanzable → GC
                  </text>
                )}
              </motion.g>
            );
          })}
        </AnimatePresence>

        {/* flechas siguiente / anterior */}
        <AnimatePresence>
          {arrows.map((ar) => (
            <motion.path
              key={ar.key}
              initial={{ d: ar.d, opacity: 0 }}
              animate={{ d: ar.d, opacity: ar.dim ? 0.15 : 1 }}
              exit={{ opacity: 0, transition: { duration: 0.35 } }}
              transition={T}
              fill="none"
              stroke={ar.changed ? COLORS.hl : ar.kind === 'sig' ? COLORS.sig : COLORS.ant}
              strokeWidth={ar.changed ? 3.4 : 2.2}
              strokeLinecap="round"
              markerEnd={mk(ar.changed ? 'hl' : ar.kind)}
              filter={ar.changed ? `url(#glow-${uid})` : undefined}
            />
          ))}
        </AnimatePresence>

        {/* inicio / fin */}
        {labels.map((lb) => {
          const w = pillW(lb.key);
          const ty = lb.target ? pos[lb.target].y - 3 : 0;
          const tx = lb.target ? cx(lb.target) + (same ? (lb.key === 'inicio' ? -14 : 14) : 0) : 0;
          return (
            <g key={lb.key}>
              <AnimatePresence>
                {lb.target && (
                  <motion.path
                    key={`${lb.key}-arrow`}
                    initial={{ d: vPath(lb.x, LABEL_Y + 12, tx, ty), opacity: 0 }}
                    animate={{ d: vPath(lb.x, LABEL_Y + 12, tx, ty), opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={T}
                    fill="none"
                    stroke={lb.changed ? COLORS.hl : COLORS.ptr}
                    strokeWidth={lb.changed ? 3 : 2}
                    markerEnd={mk(lb.changed ? 'hl' : 'ptr')}
                    filter={lb.changed ? `url(#glow-${uid})` : undefined}
                  />
                )}
              </AnimatePresence>
              <motion.g initial={false} animate={{ x: lb.x, y: LABEL_Y }} transition={T}>
                <rect
                  x={-w / 2}
                  y={-12}
                  width={w}
                  height={24}
                  rx={12}
                  fill={lb.changed ? COLORS.hl : '#6d28d9'}
                  stroke={lb.changed ? '#fef08a' : '#a78bfa'}
                  strokeWidth={1}
                />
                <text textAnchor="middle" y={4.5} fontSize={12.5} fontWeight={800} fill={lb.changed ? '#1e1b4b' : '#fff'}>
                  {lb.key}
                </text>
                {!lb.target && (
                  <text textAnchor="middle" y={34} fontSize={11.5} fill="#94a3b8" fontWeight={600}>
                    ↓ null
                  </text>
                )}
              </motion.g>
            </g>
          );
        })}

        {/* variables locales (nuevo, actual) */}
        <AnimatePresence>
          {vars.map((v) => {
            const w = pillW(v.name);
            const tp = v.target ? pos[v.target] : null;
            const d = tp ? vPath(v.x, VAR_Y - 12, cx(v.target as Addr) + v.off / 4, tp.y + NODE_H + 3) : '';
            return (
              <motion.g key={`var-${v.name}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {tp && (
                  <motion.path
                    initial={{ d, opacity: 0 }}
                    animate={{ d, opacity: 1 }}
                    transition={T}
                    fill="none"
                    stroke={v.changed ? COLORS.hl : COLORS.var}
                    strokeWidth={v.changed ? 3 : 2}
                    strokeDasharray="5 4"
                    markerEnd={mk(v.changed ? 'hl' : 'var')}
                  />
                )}
                <motion.g initial={{ x: v.x, y: VAR_Y }} animate={{ x: v.x, y: VAR_Y }} transition={T}>
                  <rect
                    x={-w / 2}
                    y={-12}
                    width={w}
                    height={24}
                    rx={12}
                    fill={v.changed ? COLORS.hl : '#78350f'}
                    stroke={COLORS.var}
                    strokeWidth={1}
                  />
                  <text textAnchor="middle" y={4.5} fontSize={12.5} fontWeight={800} fill={v.changed ? '#1c1917' : '#fde68a'}>
                    {v.name}
                  </text>
                  {!tp && (
                    <text textAnchor="middle" y={-20} fontSize={11.5} fill="#94a3b8" fontWeight={600}>
                      null ↑
                    </text>
                  )}
                </motion.g>
              </motion.g>
            );
          })}
        </AnimatePresence>

        {/* comparación actual.dato == x */}
        <AnimatePresence>
          {frame.compare && pos[frame.compare.addr] && (
            <motion.g
              key={`cmp-${frame.compare.addr}-${frame.compare.text}`}
              initial={{ opacity: 0, x: cx(frame.compare.addr), y: pos[frame.compare.addr].y + NODE_H + 12 }}
              animate={{ opacity: 1, x: cx(frame.compare.addr), y: pos[frame.compare.addr].y + NODE_H + 24 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.35 }}
            >
              <rect
                x={-(pillW(frame.compare.text) + 30) / 2}
                y={-12}
                width={pillW(frame.compare.text) + 30}
                height={24}
                rx={7}
                fill={frame.compare.ok ? '#065f46' : '#7f1d1d'}
                stroke={frame.compare.ok ? '#34d399' : '#f87171'}
              />
              <text x={-9} textAnchor="middle" y={4.5} fontSize={12} fontWeight={800} fill="#fff">
                {frame.compare.text}
              </text>
              {frame.compare.ok ? (
                <path
                  d={`M ${pillW(frame.compare.text) / 2 - 7} 0 l 4 4 l 8 -8`}
                  fill="none"
                  stroke="#6ee7b7"
                  strokeWidth={2.6}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              ) : (
                <path
                  d={`M ${pillW(frame.compare.text) / 2 - 6} -4 l 8 8 M ${pillW(frame.compare.text) / 2 + 2} -4 l -8 8`}
                  fill="none"
                  stroke="#fca5a5"
                  strokeWidth={2.6}
                  strokeLinecap="round"
                />
              )}
            </motion.g>
          )}
        </AnimatePresence>
      </svg>
    </div>
  );
}
