import {
  ArrowDown,
  ArrowLeft,
  ArrowLeftRight,
  ArrowRight,
  Boxes,
  CheckCircle2,
  Cpu,
  Database,
  Layers,
  Link2,
  Menu,
  Play,
  Puzzle,
  Recycle,
  Waypoints,
  X,
  XCircle,
} from 'lucide-react';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { NODO_CODE } from '../../lib/code';
import {
  buildState,
  chainOrder,
  emptyState,
  exampleState,
  idleFrame,
  LIST_ADDR,
  mulberry32,
  runOperation,
} from '../../lib/engine';
import { cn } from '../../utils/cn';
import { AddrText, Card, CodeBlock, highlightJava, RichText, SectionHeader } from '../common';
import { ListCanvas } from '../ListCanvas';
import { MemoryView } from '../MemoryView';
import { usePlayback } from '../player';

/* ------------------------------------------------------------------ */
/*  Navegación                                                         */
/* ------------------------------------------------------------------ */

const LINKS: [string, string][] = [
  ['nodo', 'El nodo'],
  ['memoria', 'Memoria'],
  ['simulador', 'Simulador'],
  ['metodos', 'Métodos'],
  ['orden', 'Orden'],
  ['complejidad', 'Complejidad'],
  ['consejos', 'Tu código'],
  ['quiz', 'Quiz'],
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('');

  useEffect(() => {
    const els = LINKS.map(([id]) => document.getElementById(id)).filter((e): e is HTMLElement => !!e);
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (vis[0]) setActive(vis[0].target.id);
      },
      { rootMargin: '-35% 0px -55% 0px' },
    );
    els.forEach((e) => io.observe(e));
    return () => io.disconnect();
  }, []);

  return (
    <nav className="glass sticky top-0 z-40 border-b border-slate-800/80">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <a href="#top" className="flex items-center gap-2 text-sm font-black text-white">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-400 via-violet-500 to-orange-400 font-mono text-base text-white shadow-lg shadow-violet-500/30">
            ⇄
          </span>
          <span>
            ListaMetodoDoble<span className="text-violet-300">.java</span>
          </span>
        </a>
        <div className="ml-auto hidden items-center gap-0.5 lg:flex">
          {LINKS.map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              className={cn(
                'rounded-lg px-3 py-1.5 text-[13px] font-medium transition',
                active === id ? 'bg-violet-500/15 text-violet-200' : 'text-slate-400 hover:bg-slate-800 hover:text-white',
              )}
            >
              {label}
            </a>
          ))}
        </div>
        <button
          type="button"
          className="ml-auto rounded-lg p-2 text-slate-300 hover:bg-slate-800 lg:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menú"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {open && (
        <div className="grid grid-cols-2 gap-1 border-t border-slate-800 px-4 py-3 lg:hidden">
          {LINKS.map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-slate-800"
            >
              {label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

/* ------------------------------------------------------------------ */
/*  Portada                                                            */
/* ------------------------------------------------------------------ */

export function Hero() {
  const demo = useMemo(() => {
    const rng = mulberry32(21);
    const s = buildState([10, 30, 40], rng);
    const fr = runOperation(s, { method: 'insertarDespuesDe', ref: 10, value: 20 }, rng);
    return fr.filter((f) => ['sig', 'new', 'g1', 'g2', 'g3', 'g4', 'end'].includes(f.line));
  }, []);
  const pb = usePlayback(demo, { autoplay: true, loop: true, baseDelay: 2000 });

  return (
    <header id="top" className="relative overflow-hidden">
      <div className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-violet-600/20 blur-[120px]" />
      <div className="pointer-events-none absolute -left-40 top-40 h-72 w-72 rounded-full bg-emerald-500/10 blur-[90px]" />
      <div className="pointer-events-none absolute -right-40 top-60 h-72 w-72 rounded-full bg-orange-500/10 blur-[90px]" />

      <div className="relative mx-auto max-w-7xl px-4 pb-14 pt-14 sm:px-6 sm:pt-20">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-violet-500/30 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-200">
            <Cpu size={13} /> Java · Estructuras de datos · explicado visualmente
          </div>
          <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-6xl">
            Tu lista doblemente enlazada,{' '}
            <span className="bg-gradient-to-r from-emerald-300 via-violet-300 to-orange-300 bg-clip-text text-transparent">
              dibujada paso a paso
            </span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-slate-400 sm:text-lg">
            Así funciona tu clase <code className="rounded bg-slate-800 px-1.5 py-0.5 font-mono text-[0.9em] text-cyan-300">ListaMetodoDoble</code>:
            cómo se guarda cada nodo en la memoria, qué guarda cada referencia y qué pasa{' '}
            <b className="text-slate-200">línea por línea</b> en cada uno de sus 9 métodos.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <a
              href="#simulador"
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-yellow-300 to-amber-400 px-5 py-3 text-sm font-bold text-slate-900 shadow-lg shadow-amber-500/25 transition hover:brightness-110"
            >
              <Play size={16} /> Abrir el simulador
            </a>
            <a
              href="#nodo"
              className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-5 py-3 text-sm font-bold text-slate-200 transition hover:border-slate-500"
            >
              <ArrowDown size={16} /> Empezar desde cero
            </a>
          </div>
        </div>

        <div className="relative mx-auto mt-12 max-w-5xl">
          <div className="absolute -inset-px rounded-3xl bg-gradient-to-r from-emerald-500/40 via-violet-500/40 to-orange-500/40 blur-sm" />
          <div className="relative overflow-hidden rounded-3xl border border-slate-700/60 bg-slate-950/90">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2.5">
              <span className="font-mono text-xs text-slate-400">
                demo en vivo · <span className="text-sky-300">insertarDespuesDe</span>(10, 20)
              </span>
              <code className="rounded-md bg-slate-800/90 px-2 py-0.5 font-mono text-xs ring-1 ring-slate-700">
                {highlightJava(pb.frame.title)}
              </code>
            </div>
            <div className="bg-grid">
              <ListCanvas frame={pb.frame} minSlots={4} minScale={0.5} />
            </div>
          </div>
        </div>

        <div className="mx-auto mt-10 grid max-w-5xl gap-3 sm:grid-cols-3">
          {(
            [
              [<Puzzle key="p" size={18} />, 'bg-sky-500/15 text-sky-300', 'Cada valor vive en un nodo', 'con dos referencias: anterior y siguiente.'],
              [<Waypoints key="w" size={18} />, 'bg-violet-500/15 text-violet-300', 'Los nodos están dispersos', 'en la memoria; el orden lo dan las referencias.'],
              [<ArrowLeftRight key="a" size={18} />, 'bg-emerald-500/15 text-emerald-300', 'Se puede recorrer en ambos sentidos', 'gracias a los enlaces dobles.'],
            ] as const
          ).map(([icon, tone, t, d]) => (
            <div key={t} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
              <div className={cn('flex h-9 w-9 items-center justify-center rounded-lg', tone)}>{icon}</div>
              <div className="mt-2 text-sm font-bold text-white">{t}</div>
              <div className="text-sm text-slate-400">{d}</div>
            </div>
          ))}
        </div>
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ */
/*  1 · El nodo                                                        */
/* ------------------------------------------------------------------ */

function BigNode() {
  return (
    <div className="bg-grid rounded-2xl border border-slate-800 bg-slate-950/60 p-5 sm:p-7">
      <div className="flex items-center justify-center gap-2 sm:gap-3">
        <div className="hidden shrink-0 flex-col items-end whitespace-nowrap text-right font-mono text-[11px] leading-tight text-orange-300 md:flex">
          <span>hacia el nodo</span>
          <span>de la izquierda</span>
        </div>
        <ArrowLeft className="shrink-0 text-orange-400" size={26} />
        <div className="grid grid-cols-[1fr_1.3fr_1fr] overflow-hidden rounded-xl border-2 border-slate-600 text-center font-mono shadow-2xl shadow-black/40">
          <div className="border-r border-slate-600 bg-orange-500/10 px-2 py-3 sm:px-4">
            <div className="text-[10px] font-bold uppercase tracking-wider text-orange-300">anterior</div>
            <div className="mt-1 text-sm">
              <AddrText addr="0x7A30" />
            </div>
          </div>
          <div className="relative bg-slate-900 px-3 py-3 sm:px-5">
            <div className="absolute inset-x-0 top-0 h-1" style={{ background: '#60a5fa' }} />
            <div className="text-[10px] font-bold uppercase tracking-wider text-sky-300">dato</div>
            <div className="text-3xl font-black text-white">20</div>
          </div>
          <div className="border-l border-slate-600 bg-emerald-500/10 px-2 py-3 sm:px-4">
            <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">siguiente</div>
            <div className="mt-1 text-sm">
              <AddrText addr="0x7AA8" />
            </div>
          </div>
        </div>
        <ArrowRight className="shrink-0 text-emerald-400" size={26} />
        <div className="hidden shrink-0 flex-col whitespace-nowrap font-mono text-[11px] leading-tight text-emerald-300 md:flex">
          <span>hacia el nodo</span>
          <span>de la derecha</span>
        </div>
      </div>
      <p className="mt-3 text-center font-mono text-xs text-slate-500">
        un objeto <span className="text-cyan-300">NodoDobleD</span> guardado en la dirección <AddrText addr="0x7A48" />
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-orange-500/25 bg-orange-500/5 p-3 text-sm text-slate-300">
          <b className="font-mono text-orange-300">anterior</b>
          <p className="mt-1 text-[13px] leading-snug text-slate-400">
            Guarda la <b className="text-slate-200">dirección</b> del nodo de la izquierda. Si es el primero, vale{' '}
            <code className="text-pink-400">null</code>.
          </p>
        </div>
        <div className="rounded-xl border border-sky-500/25 bg-sky-500/5 p-3 text-sm text-slate-300">
          <b className="font-mono text-sky-300">dato</b>
          <p className="mt-1 text-[13px] leading-snug text-slate-400">
            El número que guardas (<code className="text-pink-400">int</code>). Es lo único que "ve" el usuario.
          </p>
        </div>
        <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/5 p-3 text-sm text-slate-300">
          <b className="font-mono text-emerald-300">siguiente</b>
          <p className="mt-1 text-[13px] leading-snug text-slate-400">
            Guarda la dirección del nodo de la derecha. Si es el último, vale <code className="text-pink-400">null</code>.
          </p>
        </div>
      </div>
    </div>
  );
}

function BytesBar() {
  const parts = [
    { label: 'cabecera del objeto', bytes: 12, cls: 'bg-slate-700/70 text-slate-200' },
    { label: 'dato', bytes: 4, cls: 'bg-sky-500/25 text-sky-200' },
    { label: 'anterior', bytes: 4, cls: 'bg-orange-500/25 text-orange-200' },
    { label: 'siguiente', bytes: 4, cls: 'bg-emerald-500/25 text-emerald-200' },
  ];
  return (
    <Card className="mt-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h4 className="text-sm font-bold text-white">¿Cuánto ocupa un nodo en memoria?</h4>
        <span className="rounded-full bg-violet-500/15 px-2.5 py-0.5 font-mono text-xs font-bold text-violet-200">≈ 24 bytes</span>
      </div>
      <div className="flex h-14 overflow-hidden rounded-lg border border-slate-700 font-mono text-[10px]">
        {parts.map((p) => (
          <div
            key={p.label}
            style={{ flex: p.bytes }}
            className={cn('flex min-w-0 flex-col items-center justify-center border-r border-slate-950/70 px-1 text-center last:border-r-0', p.cls)}
          >
            <b className="text-xs">{p.bytes} B</b>
            <span className="w-full truncate">{p.label}</span>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs leading-relaxed text-slate-500">
        Valores típicos en una JVM HotSpot de 64 bits con <i>compressed oops</i> (depende de la JVM). Comparado con un{' '}
        <code className="text-pink-400">int[]</code>, que usa solo 4 bytes por número, cada nodo "paga" la cabecera y{' '}
        <b className="text-slate-300">dos referencias</b>. Ese es el precio de poder insertar y borrar sin mover nada.
      </p>
    </Card>
  );
}

const STATES = {
  vacia: {
    label: 'Lista vacía',
    text: '`inicio` y `fin` valen `null`: no existe ningún objeto `NodoDobleD`. Por eso `Vacia()` solo revisa `return inicio == null;`.',
  },
  uno: {
    label: 'Un solo nodo',
    text: '`inicio` y `fin` guardan **la misma dirección**, y el único nodo tiene `anterior = null` y `siguiente = null`. Por eso `eliminarInicio()` y `eliminarFinal()` tienen el caso especial `if (inicio == fin)`.',
  },
  varios: {
    label: 'Varios nodos',
    text: 'Cada nodo apunta a sus dos vecinos. El primero tiene `anterior = null` y el último `siguiente = null`: esos `null` marcan los extremos, igual que en el texto `"null <-> 10 <-> 20 <-> 30 <-> null"` que muestran tus métodos.',
  },
} as const;
type StateKey = keyof typeof STATES;

export function NodeSection() {
  const [st, setSt] = useState<StateKey>('varios');
  const frames = useMemo(
    () => ({
      vacia: idleFrame(emptyState()),
      uno: idleFrame(buildState([42], mulberry32(4))),
      varios: idleFrame(buildState([10, 20, 30], mulberry32(5))),
    }),
    [],
  );

  return (
    <section id="nodo" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="1" kicker="La pieza básica" title={<>El nodo: <span className="font-mono text-cyan-300">NodoDobleD</span></>}>
        Una lista doblemente enlazada es una <b className="text-slate-200">cadena de nodos</b>. Los números no se guardan "pegados"
        como en un arreglo: cada número vive dentro de un objeto nodo, y cada nodo conoce a sus{' '}
        <b className="text-slate-200">dos vecinos</b>.
      </SectionHeader>

      <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <BigNode />
          <BytesBar />
        </div>
        <div className="space-y-4">
          <CodeBlock lines={NODO_CODE} title="NodoDobleD.java (la clase que usa tu lista)" />
          <div className="rounded-2xl border border-amber-500/25 bg-amber-500/5 p-4 text-sm leading-relaxed text-slate-300">
            <b className="text-amber-200">Nota:</b> no incluiste <code className="font-mono text-cyan-300">NodoDobleD</code>, pero tu código usa{' '}
            <code className="font-mono">new NodoDobleD(elemento)</code>, <code className="font-mono text-sky-300">.dato</code>,{' '}
            <code className="font-mono text-emerald-300">.siguiente</code> y <code className="font-mono text-orange-300">.anterior</code>, así
            que debe ser algo como esto. Lo clave: <b className="text-white">anterior y siguiente no contienen nodos, contienen direcciones</b>{' '}
            (referencias) a otros nodos.
          </div>
        </div>
      </div>

      <div className="mt-12">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-xl font-bold text-white">Los 3 estados posibles de tu lista</h3>
          <div className="flex rounded-xl border border-slate-800 bg-slate-900/70 p-1">
            {(Object.keys(STATES) as StateKey[]).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setSt(k)}
                className={cn(
                  'rounded-lg px-3 py-1.5 text-sm font-semibold transition',
                  st === k ? 'bg-violet-500 text-white shadow' : 'text-slate-400 hover:text-white',
                )}
              >
                {STATES[k].label}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/60">
          <div className="bg-grid">
            <ListCanvas frame={frames[st]} minSlots={3} compact />
          </div>
          <div className="border-t border-slate-800 bg-slate-900/60 p-4 text-[15px] leading-relaxed text-slate-300">
            <RichText text={STATES[st].text} />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  2 · Memoria                                                        */
/* ------------------------------------------------------------------ */

function Concept({ icon, title, tone, children }: { icon: ReactNode; title: string; tone: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
      <div className={cn('mb-3 flex h-10 w-10 items-center justify-center rounded-xl', tone)}>{icon}</div>
      <h4 className="font-bold text-white">{title}</h4>
      <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{children}</p>
    </div>
  );
}

const MAIN_CODE = `public static void main(String[] args) {
    ListaMetodoDoble lista = new ListaMetodoDoble();
    lista.agregarFinal(10);
    lista.agregarFinal(20);
    lista.agregarFinal(30);
    lista.agregarFinal(40);
}`;

function ArrayVsList() {
  const arr = [10, 20, 30, 40];
  const cells: (number | 'obj' | null)[] = [null, 20, 'obj', null, 40, 10, null, 30, 'obj', null];
  const order = [5, 1, 7, 4];
  const CW = 58;
  const GX = 10;
  const X0 = 8;
  const Y0 = 78;
  const CH = 50;
  const cxOf = (i: number) => X0 + i * (CW + GX) + CW / 2;
  const width = X0 * 2 + cells.length * (CW + GX) - GX;

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card>
        <div className="mb-1 text-xs font-bold uppercase tracking-wider text-slate-500">Arreglo</div>
        <h4 className="font-mono text-sm text-white">
          {highlightJava('int[] a = {10, 20, 30, 40};')}
        </h4>
        <div className="mt-6 flex justify-center">
          {arr.map((v, i) => (
            <div key={v} className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-14 w-16 items-center justify-center border-y-2 border-r-2 border-slate-500 bg-slate-800 font-mono text-xl font-bold text-white first:border-l-2 sm:w-20',
                  i === 0 && 'rounded-l-lg border-l-2',
                  i === 3 && 'rounded-r-lg',
                  i === 2 && 'bg-yellow-400/20 text-yellow-200',
                )}
              >
                {v}
              </div>
              <span className="mt-1 font-mono text-[10px] text-slate-500">{'0x50' + (16 + i * 4).toString(16).toUpperCase()}</span>
              <span className="font-mono text-[10px] text-slate-600">a[{i}]</span>
            </div>
          ))}
        </div>
        <ul className="mt-5 space-y-2 text-sm leading-relaxed text-slate-400">
          <li>
            <CheckCircle2 size={15} className="-mt-0.5 mr-1 inline text-emerald-400" /> Celdas <b className="text-slate-200">contiguas</b>: para <code className="font-mono text-slate-200">a[2]</code> la JVM calcula{' '}
            <code className="font-mono text-yellow-200">0x5010 + 2 × 4 = 0x5018</code> → acceso directo <b className="text-emerald-300">O(1)</b>.
          </li>
          <li>
            <XCircle size={15} className="-mt-0.5 mr-1 inline text-red-400" /> Insertar al inicio obliga a <b className="text-slate-200">mover</b> todos los elementos una posición → O(n). Y su tamaño es fijo.
          </li>
        </ul>
      </Card>

      <Card>
        <div className="mb-1 text-xs font-bold uppercase tracking-wider text-slate-500">Lista doblemente enlazada</div>
        <h4 className="font-mono text-sm text-white">{highlightJava('ListaMetodoDoble lista // 10 ⇄ 20 ⇄ 30 ⇄ 40')}</h4>
        <svg viewBox={`0 0 ${width} 200`} className="mt-3 w-full" style={{ fontFamily: '"JetBrains Mono", monospace' }}>
          <defs>
            <marker id="avl-sig" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" markerUnits="userSpaceOnUse" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="#34d399" />
            </marker>
            <marker id="avl-ant" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" markerUnits="userSpaceOnUse" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="#fb923c" />
            </marker>
          </defs>
          {order.slice(0, -1).map((a, k) => {
            const b = order[k + 1];
            const h = 22 + Math.abs(a - b) * 7;
            const sx = cxOf(a) + 7;
            const tx = cxOf(b) - 7;
            return (
              <g key={k}>
                <path d={`M ${sx} ${Y0} Q ${(sx + tx) / 2} ${Y0 - h * 2} ${tx} ${Y0 - 2}`} fill="none" stroke="#34d399" strokeWidth={2} markerEnd="url(#avl-sig)" />
                <path
                  d={`M ${tx} ${Y0 + CH} Q ${(sx + tx) / 2} ${Y0 + CH + h * 1.6} ${sx} ${Y0 + CH + 2}`}
                  fill="none"
                  stroke="#fb923c"
                  strokeWidth={2}
                  markerEnd="url(#avl-ant)"
                  opacity={0.85}
                />
              </g>
            );
          })}
          {cells.map((c, i) => {
            const x = X0 + i * (CW + GX);
            const isNode = typeof c === 'number';
            return (
              <g key={i}>
                <rect
                  x={x}
                  y={Y0}
                  width={CW}
                  height={CH}
                  rx={8}
                  fill={isNode ? '#0f172a' : c === 'obj' ? 'rgba(71,85,105,0.25)' : 'transparent'}
                  stroke={isNode ? '#64748b' : '#334155'}
                  strokeDasharray={c === null ? '4 4' : undefined}
                />
                <text x={x + CW / 2} y={Y0 + CH / 2 + 6} textAnchor="middle" fontSize={isNode ? 18 : 9} fontWeight={isNode ? 800 : 400} fill={isNode ? '#fff' : '#64748b'}>
                  {isNode ? c : c === 'obj' ? 'otro obj' : 'libre'}
                </text>
                {i === 5 && (
                  <text x={x + CW / 2} y={Y0 + 12} textAnchor="middle" fontSize={8.5} fontWeight={800} fill="#c4b5fd">
                    inicio
                  </text>
                )}
                {i === 4 && (
                  <text x={x + CW / 2} y={Y0 + 12} textAnchor="middle" fontSize={8.5} fontWeight={800} fill="#c4b5fd">
                    fin
                  </text>
                )}
              </g>
            );
          })}
        </svg>
        <ul className="mt-2 space-y-2 text-sm leading-relaxed text-slate-400">
          <li>
            <CheckCircle2 size={15} className="-mt-0.5 mr-1 inline text-emerald-400" /> Los nodos quedan <b className="text-slate-200">dispersos</b> donde haya espacio. Insertar o borrar solo cambia referencias:{' '}
            <b className="text-slate-200">ningún nodo se mueve</b>.
          </li>
          <li>
            <XCircle size={15} className="-mt-0.5 mr-1 inline text-red-400" /> Para llegar al 3.º elemento hay que caminar: <code className="font-mono text-violet-300">inicio</code> →{' '}
            <code className="font-mono text-emerald-300">siguiente</code> → <code className="font-mono text-emerald-300">siguiente</code> → O(n).
          </li>
        </ul>
      </Card>
    </div>
  );
}

export function MemorySection() {
  const frame = useMemo(() => idleFrame(exampleState()), []);
  const [hovered, setHovered] = useState<string | null>(null);
  const s = frame.state;
  const order = chainOrder(s);

  const facts = [
    `En el **stack**, la variable \`lista\` de \`main\` solo guarda ${LIST_ADDR}: la dirección del objeto \`ListaMetodoDoble\`.`,
    `Ese objeto tiene solo 2 campos: \`inicio\` = ${s.inicio} y \`fin\` = ${s.fin}. **La lista no "contiene" los nodos**: solo sabe dónde está el primero y el último.`,
    `Los nodos están **desordenados** en el heap (${order.join(', ')}). El orden lógico 10 → 20 → 30 → 40 lo deciden los campos \`siguiente\`, no las direcciones.`,
    'Entre los nodos hay **otros objetos** y huecos libres: el heap es compartido por todo el programa. Por eso cada `new` cae donde haya espacio.',
  ];

  return (
    <section id="memoria" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="2" kicker="Cómo se almacena" title="¿Dónde vive todo? Stack vs Heap">
        Cuando tu programa corre, Java usa dos zonas de memoria. Entender cuál guarda qué es la clave para entender las listas
        enlazadas.
      </SectionHeader>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Concept icon={<Layers size={20} className="text-amber-300" />} tone="bg-amber-500/15" title="Stack (pila)">
          Guarda las variables locales y parámetros de cada método: <code className="font-mono text-amber-200">lista</code> en main,{' '}
          <code className="font-mono text-amber-200">nuevo</code>, <code className="font-mono text-amber-200">actual</code>,{' '}
          <code className="font-mono text-amber-200">posicion</code>… Se destruyen cuando el método termina.
        </Concept>
        <Concept icon={<Database size={20} className="text-sky-300" />} tone="bg-sky-500/15" title="Heap (montículo)">
          Guarda todo lo que creas con <code className="font-mono text-pink-400">new</code>: el objeto{' '}
          <code className="font-mono text-cyan-300">ListaMetodoDoble</code> y cada <code className="font-mono text-cyan-300">NodoDobleD</code>. Sobreviven
          mientras alguien los referencie.
        </Concept>
        <Concept icon={<Link2 size={20} className="text-violet-300" />} tone="bg-violet-500/15" title="Referencias = direcciones">
          Una variable <code className="font-mono text-cyan-300">NodoDobleD</code> no contiene el nodo, contiene su dirección. Por eso{' '}
          <code className="font-mono">actual = inicio</code> copia una dirección, no un nodo.
        </Concept>
        <Concept icon={<Recycle size={20} className="text-emerald-300" />} tone="bg-emerald-500/15" title="Garbage Collector">
          Si ningún camino desde el stack llega a un objeto, ese objeto es <b className="text-slate-200">inalcanzable</b> y Java lo borra solo.
          En Java no existe <code className="font-mono">delete</code>.
        </Concept>
      </div>

      <div className="mt-10 grid gap-5 lg:grid-cols-[340px_1fr]">
        <div className="space-y-4">
          <CodeBlock lines={MAIN_CODE} title="Main.java" />
          <Card className="p-4">
            <h4 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
              <Boxes size={16} className="text-sky-300" /> Cómo leer el dibujo
            </h4>
            <ol className="space-y-3 text-[13.5px] leading-relaxed text-slate-400">
              {facts.map((f, i) => (
                <li key={i} className="flex gap-2.5">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sky-500/20 font-mono text-[11px] font-bold text-sky-200">
                    {i + 1}
                  </span>
                  <RichText text={f} />
                </li>
              ))}
            </ol>
          </Card>
        </div>
        <div className="min-w-0 rounded-2xl border border-slate-800 bg-slate-950/60 p-3 sm:p-4">
          <MemoryView frame={frame} hovered={hovered} onHover={setHovered} />
          <p className="mt-3 text-center text-xs text-slate-500">
            Pasa el mouse sobre un nodo para resaltar solo sus enlaces. Verde = <span className="text-emerald-300">siguiente</span>, naranja ={' '}
            <span className="text-orange-300">anterior</span>, violeta = <span className="text-violet-300">inicio/fin</span>.
          </p>
        </div>
      </div>

      <div className="mt-14">
        <h3 className="mb-4 text-xl font-bold text-white">Arreglo vs. lista enlazada en memoria</h3>
        <ArrayVsList />
      </div>
    </section>
  );
}
