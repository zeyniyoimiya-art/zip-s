import { AnimatePresence } from 'framer-motion';
import { CheckCircle2, Workflow } from 'lucide-react';
import { useMemo, useState } from 'react';
import { METHOD_META, METHOD_ORDER, type MethodName } from '../../lib/code';
import { buildState, mulberry32, runOperation, type Operation } from '../../lib/engine';
import { cn } from '../../utils/cn';
import { CodePanel, highlightJava, Legend, RichText, SectionHeader } from '../common';
import { ListCanvas } from '../ListCanvas';
import { PlaybackBar, StepExplanation, SwingDialog, usePlayback, VarsPanel } from '../player';

interface GuideCase {
  label: string;
  preset: number[];
  op: Operation;
}
interface Guide {
  summary: string;
  points: string[];
  cases: GuideCase[];
}

const GUIDES: Record<MethodName, Guide> = {
  agregarInicio: {
    summary:
      'Crea un nodo nuevo y lo engancha **al principio**. No recorre la lista: siempre hace la misma cantidad de pasos, haya 3 o 3 millones de nodos.',
    points: [
      '**Lista vacía:** el nodo nuevo pasa a ser `inicio` y `fin` a la vez.',
      '**Lista con nodos:** 3 asignaciones en este orden: `nuevo.siguiente = inicio` → `inicio.anterior = nuevo` → `inicio = nuevo`.',
      '**El orden importa:** si hicieras `inicio = nuevo` primero, perderías la única referencia al antiguo primer nodo, y `nuevo.siguiente = inicio` haría que el nodo se apunte a sí mismo.',
      'Complejidad **O(1)**.',
    ],
    cases: [
      { label: 'Lista con nodos', preset: [20, 30, 40], op: { method: 'agregarInicio', value: 10 } },
      { label: 'Lista vacía', preset: [], op: { method: 'agregarInicio', value: 10 } },
    ],
  },
  agregarFinal: {
    summary:
      'Lo mismo que `agregarInicio` pero en el otro extremo. Gracias a la referencia `fin`, no hace falta recorrer la lista para encontrar el último nodo.',
    points: [
      'Sin la referencia `fin` tendrías que caminar desde `inicio` hasta el último nodo: **O(n)**. Con `fin` es **O(1)**.',
      'Primero se enlaza (`fin.siguiente = nuevo` y `nuevo.anterior = fin`) y **al final** se mueve `fin`. Si movieras `fin` antes, ya no sabrías cuál era el último.',
      'Si la lista está vacía hace lo mismo que `agregarInicio`: `inicio` y `fin` apuntan al nodo nuevo.',
    ],
    cases: [
      { label: 'Lista con nodos', preset: [10, 20, 30], op: { method: 'agregarFinal', value: 40 } },
      { label: 'Lista vacía', preset: [], op: { method: 'agregarFinal', value: 10 } },
    ],
  },
  eliminarInicio: {
    summary:
      'Quita el primer nodo: mueve `inicio` al segundo y corta el enlace hacia atrás. El nodo viejo no se "borra": se vuelve **inalcanzable** y el Garbage Collector libera su memoria.',
    points: [
      '**3 casos:** lista vacía (mensaje de error), un solo nodo (`inicio == fin` → ambos a `null`) y varios nodos.',
      '`inicio.anterior = null` es lo que vuelve **inalcanzable** al nodo viejo. Antes de esa línea, el segundo nodo todavía lo apuntaba.',
      'El nodo eliminado sigue apuntando al segundo con su `siguiente`, pero no importa: **nadie llega a él**, así que el GC lo libera.',
      'Complejidad **O(1)**.',
    ],
    cases: [
      { label: 'Varios nodos', preset: [10, 20, 30], op: { method: 'eliminarInicio' } },
      { label: 'Un solo nodo', preset: [10], op: { method: 'eliminarInicio' } },
      { label: 'Lista vacía', preset: [], op: { method: 'eliminarInicio' } },
    ],
  },
  eliminarFinal: {
    summary:
      'Quita el último nodo retrocediendo `fin` con el enlace `anterior`. Es la mejor demostración de por qué vale la pena una lista **doble**.',
    points: [
      '`fin = fin.anterior` llega al penúltimo nodo **en un solo paso**. En una lista simple no existe `anterior`: habría que recorrer desde `inicio` para hallar al penúltimo → **O(n)**.',
      'Después, `fin.siguiente = null` desconecta al viejo último, que queda inalcanzable.',
      'Mismos 3 casos que `eliminarInicio`: vacía, un nodo y varios.',
      'Complejidad **O(1)**.',
    ],
    cases: [
      { label: 'Varios nodos', preset: [10, 20, 30], op: { method: 'eliminarFinal' } },
      { label: 'Un solo nodo', preset: [10], op: { method: 'eliminarFinal' } },
      { label: 'Lista vacía', preset: [], op: { method: 'eliminarFinal' } },
    ],
  },
  buscarElemento: {
    summary:
      'Búsqueda lineal: la variable `actual` camina desde `inicio` comparando cada `dato` hasta encontrar el valor o llegar a `null`.',
    points: [
      '`actual` es solo una **copia de la dirección**: moverla no modifica la lista.',
      '`posicion` empieza en **1**, no en 0.',
      '`break` detiene el ciclo en la **primera** coincidencia: si hay valores repetidos, reporta la primera posición.',
      'Si `actual` llega a `null`, se revisaron todos los nodos sin éxito. Peor caso **O(n)**.',
    ],
    cases: [
      { label: 'Lo encuentra', preset: [10, 20, 30, 40], op: { method: 'buscarElemento', value: 30 } },
      { label: 'No existe', preset: [10, 20, 30], op: { method: 'buscarElemento', value: 99 } },
      { label: 'Lista vacía', preset: [], op: { method: 'buscarElemento', value: 5 } },
    ],
  },
  insertarDespuesDe: {
    summary:
      'Dos fases: **(1)** buscar el nodo X con `actual`; **(2)** crear el nodo nuevo y engancharlo a la **derecha** de X.',
    points: [
      '**X es el último** (`actual == fin`): se enlaza como en `agregarFinal` y se mueve `fin`.',
      '**Caso general:** 4 enlaces en orden: ① `nuevo.siguiente` ② `nuevo.anterior` ③ `actual.siguiente.anterior` ④ `actual.siguiente`.',
      'El paso ③ usa `actual.siguiente` para llegar al vecino derecho, por eso **tiene que ir antes del ④** (que sobrescribe `actual.siguiente`). Lo verás en la sección 5.',
      'Si X no existe, `return` termina el método **antes** de crear el nodo: no se desperdicia memoria.',
      'Buscar es **O(n)**, enlazar es **O(1)**.',
    ],
    cases: [
      { label: 'X en medio', preset: [10, 20, 30], op: { method: 'insertarDespuesDe', ref: 20, value: 25 } },
      { label: 'X es el último', preset: [10, 20], op: { method: 'insertarDespuesDe', ref: 20, value: 30 } },
      { label: 'X no existe', preset: [10, 20], op: { method: 'insertarDespuesDe', ref: 99, value: 5 } },
    ],
  },
  insertarAntesDe: {
    summary:
      'Igual que el anterior, pero el nodo nuevo queda a la **izquierda** de X. Aquí brilla la lista doble: `actual.anterior` te da el vecino izquierdo directamente.',
    points: [
      '**X es el primero** (`actual == inicio`): el nuevo se convierte en `inicio`, igual que en `agregarInicio`.',
      '**Caso general:** ① `nuevo.anterior` ② `nuevo.siguiente` ③ `actual.anterior.siguiente` ④ `actual.anterior`.',
      'En una lista **simple**, insertar *antes* obligaría a recordar el nodo previo durante la búsqueda. Con `anterior` no hace falta.',
      'Buscar **O(n)** + enlazar **O(1)**.',
    ],
    cases: [
      { label: 'X en medio', preset: [10, 20, 30], op: { method: 'insertarAntesDe', ref: 20, value: 15 } },
      { label: 'X es el primero', preset: [10, 20], op: { method: 'insertarAntesDe', ref: 10, value: 5 } },
      { label: 'X no existe', preset: [10, 20], op: { method: 'insertarAntesDe', ref: 99, value: 5 } },
    ],
  },
  MostrarListaInicioFin: {
    summary:
      'Recorre la lista con `siguiente` desde `inicio`, pegando cada `dato` a un `String`, y lo muestra en un `JOptionPane`.',
    points: [
      'El texto empieza con `"null <-> "` y termina con `"null"`, que simbolizan los extremos de la cadena.',
      'El ciclo `while (actual != null)` es **el patrón universal** para recorrer una lista enlazada.',
      'Cada `+` crea un `String` nuevo (son inmutables); para listas enormes conviene `StringBuilder`.',
      'Complejidad **O(n)**.',
    ],
    cases: [
      { label: 'Con nodos', preset: [10, 20, 30], op: { method: 'MostrarListaInicioFin' } },
      { label: 'Lista vacía', preset: [], op: { method: 'MostrarListaInicioFin' } },
    ],
  },
  MostrarListaFinInicio: {
    summary:
      'El mismo recorrido, pero arrancando en `fin` y usando `anterior`. Solo es posible porque la lista es **doble**.',
    points: [
      'Es una excelente **prueba** de tu código: si algún `anterior` quedó mal enlazado, este recorrido no coincidirá con el de Inicio→Fin al revés.',
      'En una lista simple, imprimir al revés requeriría recursión o una estructura auxiliar.',
      'Complejidad **O(n)**.',
    ],
    cases: [
      { label: 'Con nodos', preset: [10, 20, 30], op: { method: 'MostrarListaFinInicio' } },
      { label: 'Un solo nodo', preset: [42], op: { method: 'MostrarListaFinInicio' } },
    ],
  },
};

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const GROUP_TONE: Record<string, string> = {
  Agregar: 'text-emerald-300',
  Eliminar: 'text-red-300',
  Buscar: 'text-sky-300',
  Insertar: 'text-amber-300',
  Recorrer: 'text-violet-300',
};

export function MethodsSection() {
  const [method, setMethod] = useState<MethodName>('agregarInicio');
  const [caseIdx, setCaseIdx] = useState(0);
  const [interacted, setInteracted] = useState(false);
  const guide = GUIDES[method];
  const meta = METHOD_META[method];
  const c = guide.cases[Math.min(caseIdx, guide.cases.length - 1)];

  const frames = useMemo(() => {
    const rng = mulberry32(hash(method + c.label));
    return runOperation(buildState(c.preset, rng), c.op, rng);
  }, [method, c]);
  const pb = usePlayback(frames, { autoplay: interacted });
  const frame = pb.frame;

  const pick = (m: MethodName) => {
    setInteracted(true);
    setMethod(m);
    setCaseIdx(0);
  };

  return (
    <section id="metodos" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="4" kicker="Uno por uno" title="Método por método, caso por caso">
        Cada método tiene ramas (<code className="font-mono text-pink-400">if</code>/<code className="font-mono text-pink-400">else</code>) para
        situaciones distintas. Elige un método y un caso: la animación recorre <b className="text-slate-200">exactamente</b> las líneas que se
        ejecutan en esa situación.
      </SectionHeader>

      <div className="grid gap-5 lg:grid-cols-[250px_minmax(0,1fr)]">
        <div className="scroll-thin -mx-1 flex gap-2 overflow-x-auto px-1 pb-2 lg:mx-0 lg:flex-col lg:overflow-visible lg:px-0 lg:pb-0">
          {METHOD_ORDER.map((m) => {
            const mm = METHOD_META[m];
            const on = m === method;
            return (
              <button
                key={m}
                type="button"
                onClick={() => pick(m)}
                className={cn(
                  'shrink-0 rounded-xl border px-3 py-2.5 text-left transition lg:w-full',
                  on
                    ? 'border-violet-400/70 bg-violet-500/15 shadow-lg shadow-violet-500/10'
                    : 'border-slate-800 bg-slate-900/50 hover:border-slate-600',
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className={cn('text-[9px] font-black uppercase tracking-[0.18em]', GROUP_TONE[mm.group])}>{mm.group}</span>
                  <span
                    className={cn(
                      'rounded px-1.5 font-mono text-[10px] font-bold',
                      mm.complexity === 'O(1)' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300',
                    )}
                  >
                    {mm.complexity}
                  </span>
                </div>
                <div className={cn('mt-0.5 font-mono text-[13px] font-semibold', on ? 'text-white' : 'text-slate-300')}>{m}()</div>
                <div className="hidden text-[11.5px] leading-snug text-slate-500 lg:block">{mm.short}</div>
              </button>
            );
          })}
        </div>

        <div className="min-w-0 space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className={cn('text-[10px] font-black uppercase tracking-[0.2em]', GROUP_TONE[meta.group])}>{meta.group}</div>
                <h3 className="mt-1 break-words font-mono text-lg font-bold sm:text-xl">
                  {highlightJava(`public void ${meta.signature}`)}
                </h3>
              </div>
              <span
                className={cn(
                  'rounded-lg px-2.5 py-1 font-mono text-sm font-bold',
                  meta.complexity === 'O(1)' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300',
                )}
              >
                {meta.complexity}
              </span>
            </div>
            <p className="mt-3 text-[15px] leading-relaxed text-slate-300">
              <RichText text={guide.summary} />
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Caso:</span>
              {guide.cases.map((gc, i) => (
                <button
                  key={gc.label}
                  type="button"
                  onClick={() => {
                    setInteracted(true);
                    setCaseIdx(i);
                  }}
                  className={cn(
                    'rounded-lg border px-3 py-1.5 text-sm font-semibold transition',
                    i === caseIdx
                      ? 'border-yellow-400/60 bg-yellow-400/15 text-yellow-100'
                      : 'border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-500',
                  )}
                >
                  {gc.label}
                  <span className="ml-2 font-mono text-[11px] font-normal text-slate-400">
                    [{gc.preset.join(', ') || 'vacía'}]
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/70 shadow-xl shadow-black/30">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2.5">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Workflow size={15} className="text-violet-300" />
                <span className="font-mono text-sky-300">{method}</span>
                <span className="text-xs font-normal text-slate-500">· {c.label}</span>
              </div>
              <Legend />
            </div>
            <div className="bg-grid relative px-1 py-3">
              <ListCanvas frame={frame} minSlots={4} />
              <p className="px-3 pt-1 text-center text-[11px] text-slate-500 sm:hidden">← desliza el diagrama →</p>
              <div className="pointer-events-none absolute right-3 top-3 z-10 flex justify-end">
                <AnimatePresence>
                  {frame.dialog && <SwingDialog key={`mdlg-${pb.idx}`} dialog={frame.dialog} onOk={pb.advance} />}
                </AnimatePresence>
              </div>
            </div>
            <div className="border-t border-slate-800 bg-slate-900/70 p-4">
              <StepExplanation pb={pb} />
              <PlaybackBar pb={pb} className="mt-3" />
            </div>
          </div>

          <div className="grid gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
            <CodePanel method={method} line={frame.line} maxHeight={420} />
            <div className="space-y-4">
              <VarsPanel frame={frame} />
              <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
                <div className="mb-3 text-xs font-bold uppercase tracking-wider text-emerald-300">Claves de este método</div>
                <ul className="space-y-2.5">
                  {guide.points.map((p, i) => (
                    <li key={i} className="flex gap-2.5 text-[13.5px] leading-relaxed text-slate-300">
                      <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-400" />
                      <RichText text={p} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
