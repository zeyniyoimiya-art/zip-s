import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Code2,
  Gauge,
  Hash,
  Layers,
  Lightbulb,
  Minus,
  Recycle,
  Repeat,
  RotateCcw,
  Trophy,
  X,
  XCircle,
  Zap,
} from 'lucide-react';
import { useMemo, useState, type ReactNode } from 'react';
import { METHOD_META, METHOD_ORDER, type MethodName } from '../../lib/code';
import {
  buildState,
  chainOrder,
  cloneState,
  freeSlots,
  idleFrame,
  mulberry32,
  slotAddr,
  type Frame,
  type ListState,
} from '../../lib/engine';
import { cn } from '../../utils/cn';
import { Card, CodeBlock, highlightJava, RichText, SectionHeader } from '../common';
import { ListCanvas } from '../ListCanvas';

/* ------------------------------------------------------------------ */
/*  5 · El orden importa                                               */
/* ------------------------------------------------------------------ */

function walk(s: ListState, reverse: boolean): string {
  const out: number[] = [];
  let cur = reverse ? s.fin : s.inicio;
  let guard = 0;
  while (cur && guard++ < 20) {
    out.push(s.nodes[cur].dato);
    cur = reverse ? s.nodes[cur].anterior : s.nodes[cur].siguiente;
  }
  return ['null', ...out, 'null'].join(' <-> ');
}

const GOOD_CODE = `nuevo.siguiente = actual.siguiente;   // ①
nuevo.anterior = actual;              // ②
actual.siguiente.anterior = nuevo;    // ③
actual.siguiente = nuevo;             // ④`;

const BAD_CODE = `nuevo.siguiente = actual.siguiente;   // ①
nuevo.anterior = actual;              // ②
actual.siguiente = nuevo;             // ④ ¡antes de tiempo!
actual.siguiente.anterior = nuevo;    // ③ ahora es nuevo.anterior = nuevo`;

const BAD_INICIO = `inicio = nuevo;            // ERROR: se pierde la dirección del antiguo primero
nuevo.siguiente = inicio;  // nuevo.siguiente = nuevo  (¡se apunta a sí mismo!)
inicio.anterior = nuevo;   // nuevo.anterior = nuevo`;

function Output({ label, value, ok, note }: { label: string; value: string; ok: boolean; note?: string }) {
  return (
    <div className={cn('rounded-lg border px-3 py-2', ok ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-red-500/40 bg-red-500/10')}>
      <div className="flex items-center justify-between gap-2 font-mono text-[11.5px] font-semibold">
        <span className="text-slate-400">{label}</span>
        {ok ? <CheckCircle2 size={14} className="text-emerald-400" /> : <XCircle size={14} className="text-red-400" />}
      </div>
      <div className="mt-1 break-words font-mono text-[12.5px] text-slate-100">{value}</div>
      {note && <div className="mt-1 text-xs font-semibold text-red-300">{note}</div>}
    </div>
  );
}

export function OrderSection() {
  const { good, bad } = useMemo(() => {
    const base = buildState([10, 20, 30], mulberry32(5));
    const [A, B, C] = chainOrder(base);
    const N = slotAddr(freeSlots(base)[3]);

    const g = cloneState(base);
    g.nodes[N] = { addr: N, dato: 25, anterior: B, siguiente: C };
    g.nodes[B].siguiente = N;
    g.nodes[C].anterior = N;
    const goodF: Frame = { ...idleFrame(g), order: [A, B, N, C] };

    const b = cloneState(base);
    b.nodes[N] = { addr: N, dato: 25, anterior: N, siguiente: C };
    b.nodes[B].siguiente = N;
    const badF: Frame = {
      ...idleFrame(b),
      order: [A, B, N, C],
      raised: [N],
      changed: [`${N}.anterior`, `${C}.anterior`],
    };
    return { good: goodF, bad: badF };
  }, []);

  return (
    <section id="orden" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="5" kicker="El detalle más importante" title="¿Por qué el orden de las líneas importa?">
        En <code className="font-mono text-sky-300">insertarDespuesDe</code> tu código reconecta 4 referencias. Las mismas 4 líneas en otro orden
        producen una lista <b className="text-red-300">rota</b>. Compara:
      </SectionHeader>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="border-emerald-500/30 p-0">
          <div className="flex items-center gap-2 border-b border-slate-800 px-5 py-3 text-sm font-bold text-emerald-300">
            <CheckCircle2 size={17} /> Tu código (orden correcto)
          </div>
          <div className="space-y-4 p-5">
            <CodeBlock lines={GOOD_CODE} />
            <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/70">
              <div className="bg-grid">
                <ListCanvas frame={good} minSlots={4} minScale={0.45} compact />
              </div>
            </div>
            <div className="grid gap-2">
              <Output label="MostrarListaInicioFin()" value={walk(good.state, false)} ok />
              <Output label="MostrarListaFinInicio()" value={walk(good.state, true)} ok />
            </div>
          </div>
        </Card>

        <Card className="border-red-500/30 p-0">
          <div className="flex items-center gap-2 border-b border-slate-800 px-5 py-3 text-sm font-bold text-red-300">
            <XCircle size={17} /> Si intercambias ③ y ④
          </div>
          <div className="space-y-4 p-5">
            <CodeBlock lines={BAD_CODE} />
            <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/70">
              <div className="bg-grid">
                <ListCanvas frame={bad} minSlots={4} minScale={0.45} compact />
              </div>
            </div>
            <div className="grid gap-2">
              <Output label="MostrarListaInicioFin()" value={walk(bad.state, false)} ok />
              <Output label="MostrarListaFinInicio()" value={walk(bad.state, true)} ok={false} note="¡Falta el 25! El 30 sigue apuntando hacia atrás al 20." />
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.1fr_1fr]">
        <div className="rounded-2xl border border-yellow-400/30 bg-yellow-400/[0.06] p-5">
          <h3 className="flex items-center gap-2 font-bold text-yellow-200">
            <Lightbulb size={18} /> ¿Qué pasó?
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-slate-300">
            <RichText text="Después de `actual.siguiente = nuevo`, la expresión `actual.siguiente` **ya no es el vecino derecho (30)**: ¡es el propio nodo nuevo! Entonces `actual.siguiente.anterior = nuevo` se convierte en `nuevo.anterior = nuevo`. El 30 nunca se enteró de que tiene un vecino nuevo." />
          </p>
          <div className="mt-4 rounded-xl border border-slate-700 bg-slate-950/60 p-4">
            <div className="mb-2 text-xs font-black uppercase tracking-[0.18em] text-yellow-300">Regla de oro al reconectar</div>
            <ol className="list-inside list-decimal space-y-1.5 text-sm text-slate-300">
              <li>Primero, los enlaces del <b className="text-amber-200">nodo nuevo</b> (no rompen nada: nadie lo conoce todavía).</li>
              <li>Luego, actualiza a los <b className="text-white">vecinos</b> usando referencias que aún sean válidas.</li>
              <li>
                Al final, sobrescribe la referencia que usaste para llegar (<code className="font-mono text-emerald-300">actual.siguiente</code>,{' '}
                <code className="font-mono text-violet-300">inicio</code>, <code className="font-mono text-violet-300">fin</code>).
              </li>
            </ol>
            <p className="mt-3 text-sm font-semibold text-white">Nunca sobrescribas una referencia que todavía necesitas leer.</p>
          </div>
        </div>
        <div className="rounded-2xl border border-red-500/25 bg-red-500/[0.05] p-5">
          <h3 className="flex items-center gap-2 font-bold text-red-200">
            <AlertTriangle size={18} /> Otro ejemplo: agregarInicio al revés
          </h3>
          <CodeBlock lines={BAD_INICIO} className="mt-3" />
          <p className="mt-3 text-sm leading-relaxed text-slate-300">
            <RichText text="El nodo nuevo queda apuntándose a sí mismo y `MostrarListaInicioFin()` entraría en un **ciclo infinito** imprimiendo siempre el mismo valor. Tu versión (`nuevo.siguiente = inicio` primero, `inicio = nuevo` al final) es la correcta." />
          </p>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  6 · Complejidad                                                    */
/* ------------------------------------------------------------------ */

const WHY: Record<MethodName, string> = {
  agregarInicio: 'Solo toca `inicio` y un par de enlaces.',
  agregarFinal: 'Usa `fin` directamente: no recorre.',
  eliminarInicio: '`inicio = inicio.siguiente` y cortar un enlace.',
  eliminarFinal: '`fin = fin.anterior`: ¡gracias a la lista doble!',
  buscarElemento: 'En el peor caso compara con todos los nodos.',
  insertarDespuesDe: 'Buscar X es O(n); enlazar es O(1).',
  insertarAntesDe: 'Buscar X es O(n); enlazar es O(1).',
  MostrarListaInicioFin: 'Visita cada nodo una vez.',
  MostrarListaFinInicio: 'Visita cada nodo una vez.',
};
const CONST_STEPS: Partial<Record<MethodName, number>> = {
  agregarInicio: 4,
  agregarFinal: 4,
  eliminarInicio: 3,
  eliminarFinal: 3,
};

type Tone = 'good' | 'bad' | 'mid';
type VCell = [string, Tone];
const COMPARE: [string, VCell, VCell, VCell][] = [
  ['Acceder al elemento i', ['O(1)', 'good'], ['O(n)', 'bad'], ['O(n)', 'bad']],
  ['Insertar al inicio', ['O(n) · mover todo', 'bad'], ['O(1)', 'good'], ['O(1)', 'good']],
  ['Insertar al final', ['O(1)* si hay espacio', 'mid'], ['O(1) si guarda fin', 'mid'], ['O(1)', 'good']],
  ['Eliminar al inicio', ['O(n) · mover todo', 'bad'], ['O(1)', 'good'], ['O(1)', 'good']],
  ['Eliminar al final', ['O(1)', 'good'], ['O(n) · buscar penúltimo', 'bad'], ['O(1)', 'good']],
  ['Insertar antes de un nodo ya ubicado', ['O(n)', 'bad'], ['O(n)', 'bad'], ['O(1)', 'good']],
  ['Recorrer al revés', ['O(n)', 'good'], ['No directo', 'bad'], ['O(n)', 'good']],
  ['Memoria extra por elemento', ['Ninguna', 'good'], ['1 referencia', 'mid'], ['2 referencias', 'mid']],
];

function Verdict({ cell }: { cell: VCell }) {
  const [text, tone] = cell;
  const Icon = tone === 'good' ? Check : tone === 'bad' ? X : Minus;
  return (
    <span
      className={cn(
        'inline-flex items-start gap-1 font-mono text-[12px] leading-snug',
        tone === 'good' ? 'text-emerald-300' : tone === 'bad' ? 'text-red-300' : 'text-amber-200',
      )}
    >
      <Icon size={13} className="mt-[2px] shrink-0" />
      {text}
    </span>
  );
}

const N_VALUES = [10, 1000, 1_000_000];

export function ComplexitySection() {
  const [nIdx, setNIdx] = useState(1);
  const n = N_VALUES[nIdx];
  return (
    <section id="complejidad" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="6" kicker="¿Qué tan rápido es?" title="Complejidad de cada método">
        <b className="text-emerald-300">O(1)</b> significa "siempre la misma cantidad de pasos", sin importar cuántos nodos haya.{' '}
        <b className="text-amber-300">O(n)</b> significa "en el peor caso, un paso por cada nodo".
      </SectionHeader>

      <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <Card className="p-0">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-3">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Gauge size={16} className="text-sky-300" /> Pasos aproximados (peor caso) con
            </div>
            <div className="flex rounded-lg border border-slate-700 bg-slate-900 p-0.5">
              {N_VALUES.map((v, i) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setNIdx(i)}
                  className={cn(
                    'rounded-md px-2.5 py-1 font-mono text-xs font-bold transition',
                    i === nIdx ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white',
                  )}
                >
                  n = {v.toLocaleString('es')}
                </button>
              ))}
            </div>
          </div>
          <div className="divide-y divide-slate-800/80">
            {METHOD_ORDER.map((m) => {
              const meta = METHOD_META[m];
              const k = CONST_STEPS[m];
              const steps = k ?? n;
              const pct = k ? Math.max(1.2, (k / n) * 100) : 100;
              return (
                <div key={m} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1 px-5 py-2.5 sm:grid-cols-[210px_minmax(0,1fr)_auto]">
                  <div className="min-w-0">
                    <div className="truncate font-mono text-[13px] font-semibold text-slate-100">{m}()</div>
                    <div className="text-[11.5px] leading-snug text-slate-500">
                      <RichText text={WHY[m]} />
                    </div>
                  </div>
                  <div className="col-span-2 row-start-2 h-2.5 overflow-hidden rounded-full bg-slate-800 sm:col-span-1 sm:row-start-auto">
                    <div
                      className={cn('h-full rounded-full transition-all duration-700', k ? 'bg-emerald-400' : 'bg-amber-400')}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="col-start-2 row-start-1 text-right sm:col-start-auto sm:row-start-auto">
                    <span
                      className={cn(
                        'rounded px-1.5 font-mono text-[11px] font-bold',
                        meta.complexity === 'O(1)' ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300',
                      )}
                    >
                      {meta.complexity}
                    </span>
                    <div className="font-mono text-[11px] text-slate-500">~{steps.toLocaleString('es')} pasos</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-0">
          <div className="border-b border-slate-800 px-5 py-3 text-sm font-bold text-white">Arreglo vs. lista simple vs. tu lista doble</div>
          <div className="scroll-thin overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-[12.5px]">
              <thead>
                <tr className="text-[10px] uppercase tracking-wider text-slate-500">
                  <th className="px-4 py-2 font-bold">Operación</th>
                  <th className="px-2 py-2 font-bold">Arreglo</th>
                  <th className="px-2 py-2 font-bold">Lista simple</th>
                  <th className="px-2 py-2 font-bold text-violet-300">Lista doble</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {COMPARE.map(([op, a, s, d]) => (
                  <tr key={op}>
                    <td className="px-4 py-2 font-medium text-slate-200">{op}</td>
                    <td className="px-2 py-2">
                      <Verdict cell={a} />
                    </td>
                    <td className="px-2 py-2">
                      <Verdict cell={s} />
                    </td>
                    <td className="bg-violet-500/[0.06] px-2 py-2">
                      <Verdict cell={d} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="px-5 py-3 text-xs leading-relaxed text-slate-500">
            * Un <code className="font-mono">ArrayList</code> agrega al final en O(1) amortizado; un arreglo normal tiene tamaño fijo. La lista doble cambia
            memoria (2 referencias por nodo) por flexibilidad en ambos extremos.
          </p>
        </Card>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  7 · Observaciones sobre tu código                                  */
/* ------------------------------------------------------------------ */

const HELPER = `private NodoDobleD buscarNodo(int valor) {
    NodoDobleD actual = inicio;
    while (actual != null && actual.dato != valor) {
        actual = actual.siguiente;
    }
    return actual; // null si no existe
}

public void insertarDespuesDe(int valorReferencia, int nuevoValor) {
    NodoDobleD actual = buscarNodo(valorReferencia);
    if (actual == null) { /* mensaje: no encontrado */ return; }
    if (actual == fin) { agregarFinal(nuevoValor); return; }
    NodoDobleD nuevo = new NodoDobleD(nuevoValor);
    nuevo.siguiente = actual.siguiente;
    nuevo.anterior = actual;
    actual.siguiente.anterior = nuevo;
    actual.siguiente = nuevo;
}`;

const SB_CODE = `StringBuilder sb = new StringBuilder("null <-> ");
NodoDobleD actual = inicio;
while (actual != null) {
    sb.append(actual.dato).append(" <-> ");
    actual = actual.siguiente;
}
sb.append("null");`;

function Tip({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
      <div className="flex items-center gap-2.5">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet-500/15 text-violet-300">{icon}</span>
        <h4 className="font-bold text-white">{title}</h4>
      </div>
      <div className="mt-2 text-sm leading-relaxed text-slate-400">{children}</div>
    </div>
  );
}

export function TipsSection() {
  return (
    <section id="consejos" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="7" kicker="Revisión" title="Observaciones sobre tu código">
        Revisé los 9 métodos con todos sus casos (son las mismas simulaciones que ves arriba). Este es el resultado:
      </SectionHeader>

      <div className="mb-5 flex items-start gap-3 rounded-2xl border border-emerald-500/30 bg-emerald-500/[0.07] p-5">
        <CheckCircle2 className="mt-0.5 shrink-0 text-emerald-400" size={22} />
        <div>
          <h3 className="font-bold text-emerald-200">Tu código es correcto</h3>
          <p className="mt-1 text-sm leading-relaxed text-slate-300">
            Maneja todos los casos borde: <b className="text-white">lista vacía</b>, <b className="text-white">un solo nodo</b>, operaciones en los{' '}
            <b className="text-white">extremos</b> (actualiza <code className="font-mono text-violet-300">inicio</code>/
            <code className="font-mono text-violet-300">fin</code>) y <b className="text-white">valor no encontrado</b>. Las 4 reconexiones de las
            inserciones están en el orden correcto, y recorrer de inicio a fin da exactamente lo mismo que de fin a inicio al revés. Lo que sigue son
            mejoras opcionales de estilo y diseño.
          </p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="space-y-5">
          <Tip icon={<Recycle size={17} />} title="Reutiliza la búsqueda">
            El mismo ciclo de búsqueda aparece en <code className="font-mono text-sky-300">buscarElemento</code>,{' '}
            <code className="font-mono text-sky-300">insertarDespuesDe</code> e <code className="font-mono text-sky-300">insertarAntesDe</code>. Puedes
            extraerlo a un método privado y reutilizar <code className="font-mono text-sky-300">agregarFinal</code> en el caso especial:
            <CodeBlock lines={HELPER} className="mt-3" />
          </Tip>
        </div>
        <div className="space-y-5">
          <Tip icon={<Layers size={17} />} title="Separa la lógica de la interfaz">
            Tus métodos mezclan la estructura de datos con <code className="font-mono text-cyan-300">JOptionPane</code>. Si devolvieran valores (por ejemplo{' '}
            <code className="font-mono">{highlightJava('int buscar(int x)')}</code> que retorne la posición o -1), podrías reutilizarlos en consola, en
            pruebas o en otra interfaz, y mostrar los mensajes desde el menú.
          </Tip>
          <Tip icon={<Zap size={17} />} title="StringBuilder para mostrar">
            Cada <code className="font-mono">lista + ...</code> crea un <code className="font-mono text-cyan-300">String</code> nuevo en el heap. Para
            listas grandes es mejor:
            <CodeBlock lines={SB_CODE} className="mt-3" />
          </Tip>
          <Tip icon={<Code2 size={17} />} title="Convención de nombres">
            En Java los métodos empiezan con minúscula: <code className="font-mono text-sky-300">vacia()</code>,{' '}
            <code className="font-mono text-sky-300">mostrarListaInicioFin()</code>. No cambia el funcionamiento, pero es el estándar.
          </Tip>
          <Tip icon={<Hash size={17} />} title="Extra: contador de tamaño">
            Un campo <code className="font-mono">{highlightJava('int tamaño;')}</code> que sumes en cada agregar/insertar y restes en cada eliminar te da
            el tamaño en O(1), sin recorrer.
          </Tip>
          <Tip icon={<Repeat size={17} />} title="Elementos repetidos">
            Por el <code className="font-mono text-pink-400">break</code>, todos tus métodos con referencia actúan sobre la{' '}
            <b className="text-slate-200">primera</b> aparición del valor. Es un comportamiento válido, solo tenlo presente.
          </Tip>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  8 · Quiz                                                           */
/* ------------------------------------------------------------------ */

const QUIZ: { q: string; options: string[]; answer: number; why: string }[] = [
  {
    q: 'Si la lista tiene **un solo nodo**, ¿qué es cierto?',
    options: [
      '`inicio` y `fin` apuntan a nodos distintos',
      '`inicio == fin` y los dos enlaces del nodo son `null`',
      '`fin` vale `null`',
      'El nodo se apunta a sí mismo',
    ],
    answer: 1,
    why: 'Con un solo nodo, `inicio` y `fin` guardan la misma dirección y el nodo no tiene vecinos. Por eso existe el caso `if (inicio == fin)`.',
  },
  {
    q: 'En `actual = inicio;`, ¿qué se copia?',
    options: ['El nodo completo (dato y enlaces)', 'Solo el dato del primer nodo', 'La dirección (referencia) del primer nodo', 'Toda la lista'],
    answer: 2,
    why: 'Las variables de tipo objeto guardan referencias: `actual` e `inicio` pasan a señalar al mismo objeto. No se duplica nada.',
  },
  {
    q: 'Lista `10 ⇄ 20 ⇄ 30`. Después de `eliminarFinal()`, ¿cuánto vale `fin.siguiente`?',
    options: ['La dirección del nodo 30', '`null`', 'La dirección del nodo 10', 'No se puede saber'],
    answer: 1,
    why: 'Primero `fin = fin.anterior` (fin pasa al 20) y luego `fin.siguiente = null` corta el enlace con el 30.',
  },
  {
    q: '¿Por qué `eliminarFinal()` es **O(1)** en tu lista doble, pero sería O(n) en una lista simple?',
    options: [
      'Porque Java optimiza las listas dobles',
      'Porque `fin.anterior` da el penúltimo nodo sin recorrer la lista',
      'Porque la lista doble guarda los nodos contiguos',
      'Porque usa un arreglo interno',
    ],
    answer: 1,
    why: 'En una lista simple no hay enlace hacia atrás: para encontrar el penúltimo habría que caminar desde `inicio`.',
  },
  {
    q: 'Lista `5 ⇄ 8`. Llamas `insertarAntesDe(5, 1)`. ¿Qué rama se ejecuta?',
    options: ['`if (!hallado)`', '`if (actual == inicio)` (caso especial)', 'El caso general de 4 punteros', '`if (Vacia())`'],
    answer: 1,
    why: 'El 5 es el primer nodo, así que el nuevo debe convertirse en `inicio`: `nuevo.siguiente = inicio; inicio.anterior = nuevo; inicio = nuevo;`.',
  },
  {
    q: 'Después de `eliminarInicio()`, ¿qué pasa con el nodo eliminado?',
    options: [
      'Se borra al instante con `delete`',
      'Queda en el heap hasta que el Garbage Collector lo libera, porque nadie lo referencia',
      'Se mueve al final de la lista',
      'Queda guardado en `inicio.anterior`',
    ],
    answer: 1,
    why: 'Java no tiene `delete`. Al hacer `inicio.anterior = null`, el nodo queda inalcanzable y el GC recupera su memoria.',
  },
  {
    q: '`buscarElemento(7)` en la lista `7 ⇄ 3 ⇄ 7`: ¿qué posición reporta?',
    options: ['1', '3', '1 y 3', '0'],
    answer: 0,
    why: '`posicion` empieza en 1 y el `break` detiene el ciclo en la primera coincidencia.',
  },
  {
    q: '¿Qué muestra `MostrarListaFinInicio()` para la lista `1 ⇄ 2 ⇄ 3`?',
    options: [
      '`null <-> 1 <-> 2 <-> 3 <-> null`',
      '`null <-> 3 <-> 2 <-> 1 <-> null`',
      '`3 <-> 2 <-> 1`',
      '`null <-> 3 <-> 2 <-> 1`',
    ],
    answer: 1,
    why: 'Empieza con `"null <-> "`, recorre desde `fin` usando `anterior` y termina agregando `"null"`.',
  },
];

export function QuizSection() {
  const [picked, setPicked] = useState<(number | null)[]>(() => QUIZ.map(() => null));
  const answered = picked.filter((p) => p !== null).length;
  const score = picked.filter((p, i) => p === QUIZ[i].answer).length;

  return (
    <section id="quiz" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-20 sm:px-6">
      <SectionHeader num="8" kicker="Ponte a prueba" title="Quiz rápido">
        8 preguntas para comprobar que entendiste cómo se mueven las referencias.
      </SectionHeader>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-2">
          <Trophy size={18} className="text-yellow-300" />
          <span className="font-mono text-sm text-slate-200">
            Aciertos: <b className="text-yellow-200">{score}</b> / {QUIZ.length}
          </span>
          <span className="text-xs text-slate-500">({answered} respondidas)</span>
        </div>
        {answered > 0 && (
          <button
            type="button"
            onClick={() => setPicked(QUIZ.map(() => null))}
            className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/70 px-3 py-2 text-xs text-slate-200 hover:bg-slate-700"
          >
            <RotateCcw size={13} /> Reiniciar
          </button>
        )}
        {answered === QUIZ.length && (
          <span className="text-sm font-semibold text-emerald-300">
            {score === QUIZ.length ? '¡Perfecto! Dominas las listas dobles.' : score >= 6 ? '¡Muy bien!' : 'Repasa el simulador y vuelve a intentarlo.'}
          </span>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {QUIZ.map((item, qi) => {
          const p = picked[qi];
          return (
            <div key={qi} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5">
              <div className="flex gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-violet-500/20 font-mono text-sm font-bold text-violet-200">
                  {qi + 1}
                </span>
                <p className="pt-0.5 text-[15px] font-semibold leading-snug text-white">
                  <RichText text={item.q} />
                </p>
              </div>
              <div className="mt-4 grid gap-2">
                {item.options.map((opt, oi) => {
                  const isAns = oi === item.answer;
                  const isPicked = p === oi;
                  return (
                    <button
                      key={oi}
                      type="button"
                      disabled={p !== null}
                      onClick={() => setPicked((arr) => arr.map((v, i) => (i === qi ? oi : v)))}
                      className={cn(
                        'flex items-center gap-2 rounded-lg border px-3 py-2 text-left text-sm transition',
                        p === null && 'border-slate-700 bg-slate-800/40 text-slate-300 hover:border-violet-400/60 hover:bg-violet-500/10',
                        p !== null && isAns && 'border-emerald-500/60 bg-emerald-500/10 text-emerald-100',
                        p !== null && isPicked && !isAns && 'border-red-500/60 bg-red-500/10 text-red-100',
                        p !== null && !isAns && !isPicked && 'border-slate-800 bg-slate-900/30 text-slate-500',
                      )}
                    >
                      <span className="font-mono text-xs text-slate-500">{String.fromCharCode(65 + oi)}</span>
                      <span className="flex-1">
                        <RichText text={opt} />
                      </span>
                      {p !== null && isAns && <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />}
                      {p !== null && isPicked && !isAns && <XCircle size={16} className="shrink-0 text-red-400" />}
                    </button>
                  );
                })}
              </div>
              {p !== null && (
                <div
                  className={cn(
                    'mt-3 rounded-lg px-3 py-2 text-[13px] leading-relaxed',
                    p === item.answer ? 'bg-emerald-500/10 text-emerald-100' : 'bg-amber-500/10 text-amber-100',
                  )}
                >
                  <b>{p === item.answer ? '¡Correcto! ' : 'No exactamente. '}</b>
                  <RichText text={item.why} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950/60">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-8 text-center text-sm text-slate-500 sm:flex-row sm:px-6 sm:text-left">
        <p>
          Explicación visual de <code className="font-mono text-cyan-300">ListaMetodoDoble</code> (código de <b className="text-slate-300">Zenith</b>).
        </p>
        <p className="text-xs">Las direcciones de memoria (0x7A…) son ilustrativas: Java no expone direcciones reales, pero las referencias funcionan así.</p>
      </div>
    </footer>
  );
}
