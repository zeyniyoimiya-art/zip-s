import { AnimatePresence } from 'framer-motion';
import {
  Eraser,
  Eye,
  EyeOff,
  Keyboard,
  MemoryStick,
  RotateCcw,
  Shuffle,
  Workflow,
} from 'lucide-react';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  buildState,
  exampleState,
  idleFrame,
  listValues,
  MAX_NODES,
  opLabel,
  runOperation,
  type Frame,
  type Operation,
} from '../lib/engine';
import { cn } from '../utils/cn';
import { CodePanel, Legend } from './common';
import { ListCanvas } from './ListCanvas';
import { MemoryView } from './MemoryView';
import {
  MiniPlayer,
  PlaybackBar,
  StepExplanation,
  SwingDialog,
  usePlayback,
  useInView,
  VarsPanel,
} from './player';


const INTRO =
  'Esta lista se creó con `new ListaMetodoDoble()` y luego `agregarFinal(10)`, `agregarFinal(20)`, `agregarFinal(30)` y `agregarFinal(40)`. Elige una operación: verás **qué línea se ejecuta**, **qué referencia cambia** y **cómo queda la memoria**.';
const CTOR_MSG =
  '`new ListaMetodoDoble()` crea el objeto lista en el heap y el constructor deja `inicio = null` y `fin = null`. Todavía no existe ningún nodo. Prueba `agregarInicio` o `agregarFinal`.';

type Tone = 'emerald' | 'red' | 'sky' | 'amber' | 'violet';
const TONES: Record<Tone, { title: string; btn: string }> = {
  emerald: { title: 'text-emerald-300', btn: 'border-emerald-500/30 hover:border-emerald-400 hover:bg-emerald-500/10' },
  red: { title: 'text-red-300', btn: 'border-red-500/30 hover:border-red-400 hover:bg-red-500/10' },
  sky: { title: 'text-sky-300', btn: 'border-sky-500/30 hover:border-sky-400 hover:bg-sky-500/10' },
  amber: { title: 'text-amber-300', btn: 'border-amber-500/30 hover:border-amber-400 hover:bg-amber-500/10' },
  violet: { title: 'text-violet-300', btn: 'border-violet-500/30 hover:border-violet-400 hover:bg-violet-500/10' },
};

function OpGroup({ title, tone, children }: { title: string; tone: Tone; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className={cn('text-[10px] font-black uppercase tracking-[0.18em]', TONES[tone].title)}>{title}</span>
      {children}
    </div>
  );
}

function OpButton({
  tone,
  onClick,
  disabled,
  children,
  title,
}: {
  tone: Tone;
  onClick: () => void;
  disabled?: boolean;
  children: ReactNode;
  title?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'truncate rounded-lg border bg-slate-900/80 px-3 py-2 text-left font-mono text-[12px] text-slate-100 transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40',
        TONES[tone].btn,
      )}
    >
      {children}
    </button>
  );
}

function SmallBtn({ onClick, children, title }: { onClick: () => void; children: ReactNode; title?: string }) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/70 px-2.5 py-1.5 text-xs text-slate-200 transition hover:border-slate-500 hover:bg-slate-700"
    >
      {children}
    </button>
  );
}

export function Simulator() {
  const [frames, setFrames] = useState<Frame[]>(() => [
    idleFrame(exampleState(), INTRO, 'Lista de ejemplo'),
  ]);
  const pb = usePlayback(frames, { autoplay: true });
  const frame = pb.frame;
  const finalState = frames[frames.length - 1].state;
  const values = listValues(finalState);
  const full = values.length >= MAX_NODES;

  const [valStr, setValStr] = useState('25');
  const [refStr, setRefStr] = useState('20');
  const [hovered, setHovered] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [memArrows, setMemArrows] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const sectionVisible = useInView(sectionRef, 0.04);
  const canvasVisible = useInView(canvasRef, 0.2);

  const pbRef = useRef(pb);
  useEffect(() => {
    pbRef.current = pb;
  });

  useEffect(() => {
    if (!canvasVisible) return;
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && ['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON'].includes(t.tagName)) return;
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        pbRef.current.next();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        pbRef.current.prev();
      } else if (e.key === ' ') {
        e.preventDefault();
        pbRef.current.toggle();
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [canvasVisible]);

  const parseNum = (s: string): number | null => {
    if (s.trim() === '') return null;
    const n = Number(s);
    return Number.isInteger(n) && Math.abs(n) <= 9999 ? n : null;
  };

  const run = (op: Operation) => {
    setErr(null);
    setFrames(runOperation(finalState, op));
    setHistory((h) => [opLabel(op), ...h].slice(0, 8));
  };

  const withValue = (fn: (v: number) => Operation) => {
    const v = parseNum(valStr);
    if (v === null) {
      setErr('Escribe un número entero válido (entre -9999 y 9999) en «valor».');
      return;
    }
    run(fn(v));
  };

  const insert = (method: 'insertarDespuesDe' | 'insertarAntesDe') => {
    const v = parseNum(valStr);
    const r = parseNum(refStr);
    if (v === null || r === null) {
      setErr('Escribe números enteros válidos en «valor» y en «referencia X».');
      return;
    }
    run({ method, ref: r, value: v });
  };

  const reset = (vals: number[] | 'example', msg: string, title: string) => {
    setErr(null);
    setFrames([idleFrame(vals === 'example' ? exampleState() : buildState(vals), msg, title)]);
    setHistory([]);
  };

  const randomValue = () => {
    let v = 1;
    for (let i = 0; i < 60; i++) {
      v = 1 + Math.floor(Math.random() * 99);
      if (!values.includes(v)) break;
    }
    setValStr(String(v));
  };

  const randomList = () => {
    const len = 3 + Math.floor(Math.random() * 3);
    const set = new Set<number>();
    while (set.size < len) set.add(1 + Math.floor(Math.random() * 99));
    const vals = [...set];
    reset(vals, `Lista aleatoria creada con ${vals.length} llamadas a \`agregarFinal\`. Observa en la vista de memoria que los nodos quedan **dispersos** en el heap.`, 'Lista aleatoria');
    setRefStr(String(vals[1]));
  };

  const v = valStr || '?';
  const r = refStr || '?';

  return (
    <div ref={sectionRef}>
      {/* ---------------- Controles ---------------- */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 shadow-xl shadow-black/20">
        <div className="flex flex-wrap items-end gap-4">
          <label className="flex flex-col gap-1">
            <span className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">valor (elemento)</span>
            <div className="flex">
              <input
                type="number"
                value={valStr}
                onChange={(e) => setValStr(e.target.value)}
                className="h-10 w-28 rounded-l-lg border border-slate-700 bg-slate-950 px-3 font-mono text-sm text-white outline-none focus:border-yellow-400"
              />
              <button
                type="button"
                onClick={randomValue}
                title="Valor aleatorio"
                className="flex h-10 w-10 items-center justify-center rounded-r-lg border border-l-0 border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                <Shuffle size={15} />
              </button>
            </div>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">referencia X</span>
            <input
              type="number"
              value={refStr}
              onChange={(e) => setRefStr(e.target.value)}
              className="h-10 w-28 rounded-lg border border-slate-700 bg-slate-950 px-3 font-mono text-sm text-white outline-none focus:border-violet-400"
            />
          </label>
          <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5 pb-1.5">
            <span className="text-[11px] text-slate-500">Usar como X:</span>
            {values.length === 0 && <span className="text-[11px] italic text-slate-600">(lista vacía)</span>}
            {values.map((val, i) => (
              <button
                key={`${val}-${i}`}
                type="button"
                onClick={() => setRefStr(String(val))}
                className={cn(
                  'rounded-md px-2 py-0.5 font-mono text-xs transition',
                  String(val) === refStr ? 'bg-violet-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700',
                )}
              >
                {val}
              </button>
            ))}
          </div>
        </div>
        {err && <p className="mt-2 text-xs font-medium text-red-400">{err}</p>}

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          <OpGroup title="Agregar" tone="emerald">
            <OpButton tone="emerald" disabled={full} onClick={() => withValue((x) => ({ method: 'agregarInicio', value: x }))}>
              agregarInicio({v})
            </OpButton>
            <OpButton tone="emerald" disabled={full} onClick={() => withValue((x) => ({ method: 'agregarFinal', value: x }))}>
              agregarFinal({v})
            </OpButton>
          </OpGroup>
          <OpGroup title="Eliminar" tone="red">
            <OpButton tone="red" onClick={() => run({ method: 'eliminarInicio' })}>
              eliminarInicio()
            </OpButton>
            <OpButton tone="red" onClick={() => run({ method: 'eliminarFinal' })}>
              eliminarFinal()
            </OpButton>
          </OpGroup>
          <OpGroup title="Buscar" tone="sky">
            <OpButton tone="sky" onClick={() => withValue((x) => ({ method: 'buscarElemento', value: x }))}>
              buscarElemento({v})
            </OpButton>
          </OpGroup>
          <OpGroup title="Insertar" tone="amber">
            <OpButton tone="amber" disabled={full} onClick={() => insert('insertarDespuesDe')}>
              insertarDespuesDe({r}, {v})
            </OpButton>
            <OpButton tone="amber" disabled={full} onClick={() => insert('insertarAntesDe')}>
              insertarAntesDe({r}, {v})
            </OpButton>
          </OpGroup>
          <OpGroup title="Recorrer" tone="violet">
            <OpButton tone="violet" onClick={() => run({ method: 'MostrarListaInicioFin' })}>
              MostrarListaInicioFin()
            </OpButton>
            <OpButton tone="violet" onClick={() => run({ method: 'MostrarListaFinInicio' })}>
              MostrarListaFinInicio()
            </OpButton>
          </OpGroup>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-800 pt-3">
          <span className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">Reiniciar lista</span>
          <SmallBtn onClick={() => reset('example', INTRO, 'Lista de ejemplo')}>
            <RotateCcw size={13} /> Ejemplo 10·20·30·40
          </SmallBtn>
          <SmallBtn onClick={randomList}>
            <Shuffle size={13} /> Aleatoria
          </SmallBtn>
          <SmallBtn onClick={() => reset([], CTOR_MSG, 'new ListaMetodoDoble()')} title="Lista recién creada">
            <Eraser size={13} /> new ListaMetodoDoble()
          </SmallBtn>
          {full && <span className="text-xs text-amber-300">Máximo {MAX_NODES} nodos en el simulador.</span>}
          <span className="ml-auto hidden items-center gap-1.5 text-[11px] text-slate-500 md:flex">
            <Keyboard size={13} /> con el diagrama a la vista: ← → pasos · espacio = play/pausa
          </span>
        </div>
      </div>

      {/* ---------------- Vista lógica + código ---------------- */}
      <div className="mt-4 grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_400px]">
        <div ref={canvasRef} className="min-w-0 overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/70 shadow-xl shadow-black/30">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2.5">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Workflow size={15} className="text-violet-300" /> Vista lógica
              <span className="text-xs font-normal text-slate-500">cómo la dibujamos</span>
            </div>
            <Legend />
          </div>
          <div className="bg-grid relative px-1 py-3">
            <ListCanvas frame={frame} hovered={hovered} onHover={setHovered} />
            <p className="px-3 pt-1 text-center text-[11px] text-slate-500 sm:hidden">← desliza el diagrama →</p>
            <div className="pointer-events-none absolute right-3 top-3 z-10 flex justify-end">
              <AnimatePresence>
                {frame.dialog && <SwingDialog key={`dlg-${pb.idx}`} dialog={frame.dialog} onOk={pb.advance} />}
              </AnimatePresence>
            </div>
          </div>
          <div className="border-t border-slate-800 bg-slate-900/70 p-4">
            <StepExplanation pb={pb} />
            <PlaybackBar pb={pb} className="mt-3" />
          </div>
        </div>

        <div className="min-w-0 xl:sticky xl:top-20 xl:row-span-2 xl:self-start">
          <CodePanel method={frame.method} line={frame.line} maxHeight={560} />
        </div>

        <div className="grid min-w-0 gap-4 md:grid-cols-2">
          <VarsPanel frame={frame} />
          {history.length > 0 ? (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
              <div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Historial</div>
              <div className="flex flex-wrap gap-1.5">
                {history.map((h, i) => (
                  <span
                    key={`${h}-${i}`}
                    className={cn(
                      'rounded-md px-2 py-0.5 font-mono text-[11px]',
                      i === 0 ? 'bg-yellow-400/15 text-yellow-200' : 'bg-slate-800 text-slate-400',
                    )}
                  >
                    {h}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center rounded-2xl border border-dashed border-slate-800 p-4 text-xs leading-relaxed text-slate-500">
              Consejo: pasa el mouse sobre un nodo del diagrama o de la memoria para resaltar sus enlaces en ambas vistas.
            </div>
          )}
        </div>
      </div>

      {/* ---------------- Vista de memoria ---------------- */}
      <div className="mt-4 overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/70 shadow-xl shadow-black/30">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2.5">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <MemoryStick size={15} className="text-sky-300" /> Vista de memoria
            <span className="text-xs font-normal text-slate-500">cómo está guardada de verdad · pasa el mouse sobre un nodo</span>
          </div>
          <button
            type="button"
            onClick={() => setMemArrows((a) => !a)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/70 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-700"
          >
            {memArrows ? <EyeOff size={13} /> : <Eye size={13} />}
            {memArrows ? 'Ocultar flechas' : 'Mostrar flechas'}
          </button>
        </div>
        <div className="p-3 sm:p-4">
          <MemoryView frame={frame} hovered={hovered} onHover={setHovered} showArrows={memArrows} />
        </div>
      </div>

      <MiniPlayer
        pb={pb}
        visible={sectionVisible && !canvasVisible}
        onJump={() => canvasRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })}
      />
    </div>
  );
}
