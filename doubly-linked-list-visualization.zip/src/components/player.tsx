import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertTriangle,
  ArrowUp,
  Info,
  Pause,
  Play,
  RotateCcw,
  SkipBack,
  SkipForward,
  StepBack,
  StepForward,
  XCircle,
} from 'lucide-react';
import { useEffect, useState, type ReactNode, type RefObject } from 'react';
import type { DialogData, Frame } from '../lib/engine';
import { cn } from '../utils/cn';
import { AddrText, highlightJava, RichText } from './common';
import { VarValueView, varType } from './MemoryView';

/* ------------------------------------------------------------------ */
/*  Hook de reproducción                                               */
/* ------------------------------------------------------------------ */

export interface Playback {
  frames: Frame[];
  frame: Frame;
  idx: number;
  total: number;
  playing: boolean;
  speed: number;
  setSpeed: (s: number) => void;
  toggle: () => void;
  play: () => void;
  pause: () => void;
  next: () => void;
  prev: () => void;
  first: () => void;
  last: () => void;
  seek: (i: number) => void;
  advance: () => void;
}

interface PbState {
  frames: Frame[];
  idx: number;
  playing: boolean;
}

export function usePlayback(
  frames: Frame[],
  { autoplay = false, loop = false, baseDelay = 1700 }: { autoplay?: boolean; loop?: boolean; baseDelay?: number } = {},
): Playback {
  const [st, setSt] = useState<PbState>({ frames, idx: 0, playing: autoplay });
  const [speed, setSpeed] = useState(1);

  let cur = st;
  if (st.frames !== frames) {
    cur = { frames, idx: 0, playing: autoplay };
    setSt(cur);
  }
  const total = frames.length;
  const idx = Math.min(cur.idx, total - 1);
  const playing = cur.playing;

  useEffect(() => {
    if (!playing) return;
    if (idx >= total - 1) {
      if (loop) {
        const t = window.setTimeout(() => setSt((s) => ({ ...s, idx: 0 })), 3400);
        return () => window.clearTimeout(t);
      }
      setSt((s) => ({ ...s, playing: false }));
      return;
    }
    const f = frames[idx];
    const delay = (f.dialog ? baseDelay * 1.5 : baseDelay) / speed;
    const t = window.setTimeout(
      () => setSt((s) => ({ ...s, idx: Math.min(s.idx + 1, s.frames.length - 1) })),
      delay,
    );
    return () => window.clearTimeout(t);
  }, [playing, idx, total, frames, speed, loop, baseDelay]);

  const clamp = (s: PbState, i: number) => Math.max(0, Math.min(i, s.frames.length - 1));
  const restartIfEnd = (s: PbState) => (s.idx >= s.frames.length - 1 ? 0 : s.idx);

  return {
    frames,
    frame: frames[idx],
    idx,
    total,
    playing,
    speed,
    setSpeed,
    play: () => setSt((s) => ({ ...s, playing: true, idx: restartIfEnd(s) })),
    pause: () => setSt((s) => ({ ...s, playing: false })),
    toggle: () =>
      setSt((s) => (s.playing ? { ...s, playing: false } : { ...s, playing: true, idx: restartIfEnd(s) })),
    next: () => setSt((s) => ({ ...s, playing: false, idx: clamp(s, s.idx + 1) })),
    prev: () => setSt((s) => ({ ...s, playing: false, idx: clamp(s, s.idx - 1) })),
    first: () => setSt((s) => ({ ...s, playing: false, idx: 0 })),
    last: () => setSt((s) => ({ ...s, playing: false, idx: s.frames.length - 1 })),
    seek: (i: number) => setSt((s) => ({ ...s, playing: false, idx: clamp(s, i) })),
    advance: () => setSt((s) => ({ ...s, idx: clamp(s, s.idx + 1) })),
  };
}

export function useInView<T extends Element>(ref: RefObject<T | null>, threshold = 0.1): boolean {
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => setV(e.isIntersecting && e.intersectionRatio >= threshold * 0.98),
      { threshold: [0, threshold, Math.min(1, threshold * 2)] },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [ref, threshold]);
  return v;
}

/* ------------------------------------------------------------------ */
/*  Controles                                                          */
/* ------------------------------------------------------------------ */

function IconBtn({
  children,
  onClick,
  title,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  title: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      disabled={disabled}
      className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-700 bg-slate-800/80 text-slate-200 transition hover:border-slate-500 hover:bg-slate-700 active:scale-95 disabled:cursor-not-allowed disabled:opacity-35"
    >
      {children}
    </button>
  );
}

export function PlaybackBar({ pb, className }: { pb: Playback; className?: string }) {
  const atEnd = pb.idx >= pb.total - 1;
  const canReplay = atEnd && pb.total > 1;
  return (
    <div className={cn('flex flex-wrap items-center gap-2', className)}>
      <div className="flex items-center gap-1">
        <IconBtn title="Primer paso" onClick={pb.first} disabled={pb.idx === 0}>
          <SkipBack size={16} />
        </IconBtn>
        <IconBtn title="Paso anterior (←)" onClick={pb.prev} disabled={pb.idx === 0}>
          <StepBack size={16} />
        </IconBtn>
        <button
          type="button"
          onClick={pb.toggle}
          disabled={pb.total <= 1}
          className="flex h-9 min-w-[124px] items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-yellow-300 to-amber-400 px-4 text-sm font-bold text-slate-900 shadow-lg shadow-amber-500/20 transition hover:brightness-110 active:scale-95 disabled:opacity-40"
        >
          {pb.playing ? <Pause size={16} /> : canReplay ? <RotateCcw size={16} /> : <Play size={16} />}
          {pb.playing ? 'Pausa' : canReplay ? 'Repetir' : 'Reproducir'}
        </button>
        <IconBtn title="Paso siguiente (→)" onClick={pb.next} disabled={atEnd}>
          <StepForward size={16} />
        </IconBtn>
        <IconBtn title="Último paso" onClick={pb.last} disabled={atEnd}>
          <SkipForward size={16} />
        </IconBtn>
      </div>
      <div className="flex min-w-[150px] flex-1 items-center gap-2">
        <input
          type="range"
          min={0}
          max={Math.max(0, pb.total - 1)}
          value={pb.idx}
          onChange={(e) => pb.seek(Number(e.target.value))}
          disabled={pb.total <= 1}
          aria-label="Línea de tiempo"
          className="h-1.5 flex-1 cursor-pointer accent-yellow-400"
        />
        <span className="w-12 text-right font-mono text-xs text-slate-400">
          {pb.idx + 1}/{pb.total}
        </span>
      </div>
      <select
        value={pb.speed}
        onChange={(e) => pb.setSpeed(Number(e.target.value))}
        aria-label="Velocidad"
        className="h-9 rounded-lg border border-slate-700 bg-slate-800 px-2 font-mono text-xs text-slate-200 outline-none focus:border-yellow-400"
      >
        {[0.5, 1, 1.5, 2, 3].map((s) => (
          <option key={s} value={s}>
            {s}×
          </option>
        ))}
      </select>
    </div>
  );
}

export function StepExplanation({ pb, className }: { pb: Playback; className?: string }) {
  const f = pb.frame;
  return (
    <div className={className}>
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <span className="rounded-md bg-yellow-400/15 px-2 py-0.5 font-mono text-[11px] font-bold tracking-wide text-yellow-300">
          PASO {pb.idx + 1}/{pb.total}
        </span>
        <code className="rounded-md bg-slate-800/90 px-2 py-0.5 font-mono text-[12.5px] ring-1 ring-slate-700">
          {highlightJava(f.title)}
        </code>
      </div>
      <AnimatePresence mode="wait" initial={false}>
        <motion.p
          key={`${pb.idx}-${f.title}-${f.message.length}`}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="min-h-[3.2em] text-[14px] leading-relaxed text-slate-300"
        >
          <RichText text={f.message} />
        </motion.p>
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  JOptionPane simulado                                               */
/* ------------------------------------------------------------------ */

export function SwingDialog({ dialog, onOk }: { dialog: DialogData; onOk?: () => void }) {
  const icon =
    dialog.type === 'error' ? (
      <XCircle className="text-red-600" size={30} />
    ) : dialog.type === 'warning' ? (
      <AlertTriangle className="text-amber-500" size={30} />
    ) : (
      <Info className="text-sky-600" size={30} />
    );
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: -8 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.22 }}
      className="pointer-events-auto w-[min(88vw,390px)] overflow-hidden rounded-md border border-slate-500 bg-[#eef1f6] text-slate-800 shadow-2xl shadow-black/60"
      role="dialog"
      aria-label={dialog.title}
    >
      <div className="flex items-center justify-between border-b border-slate-400 bg-gradient-to-b from-[#e3e9f2] to-[#c8d2e0] px-3 py-1.5 text-xs font-bold">
        <span className="flex items-center gap-2">
          <span className="flex h-3.5 w-3.5 items-center justify-center rounded-sm bg-gradient-to-br from-orange-400 to-red-500 text-[8px] text-white">
            J
          </span>
          {dialog.title}
        </span>
        <span className="text-sm leading-none text-slate-500">×</span>
      </div>
      <div className="flex items-start gap-3 px-4 pb-2 pt-4">
        <div className="shrink-0">{icon}</div>
        <p className="break-words pt-1 text-[13px] leading-snug" style={{ fontFamily: 'Tahoma, Verdana, sans-serif' }}>
          {dialog.message}
        </p>
      </div>
      <div className="flex justify-end px-4 pb-3">
        <button
          type="button"
          onClick={onOk}
          className="rounded border border-slate-400 bg-gradient-to-b from-white to-slate-200 px-6 py-1 text-xs font-semibold shadow-sm hover:from-sky-50 hover:to-sky-100"
        >
          OK
        </button>
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Variables locales                                                  */
/* ------------------------------------------------------------------ */

export function VarsPanel({ frame, className }: { frame: Frame; className?: string }) {
  return (
    <div className={cn('rounded-2xl border border-slate-800 bg-slate-900/50 p-4', className)}>
      <div className="mb-2.5 flex items-center justify-between gap-2">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-300">Variables locales</span>
        <span className="truncate font-mono text-[11px] text-slate-500">
          {frame.method && !frame.done ? `${frame.method}()` : 'ninguna'}
        </span>
      </div>
      {frame.vars.length === 0 ? (
        <p className="text-xs leading-relaxed text-slate-500">
          {frame.method && !frame.done
            ? 'Este método no declara parámetros ni variables locales: trabaja directamente con los campos inicio y fin del objeto.'
            : 'No hay variables locales vivas. Solo existen mientras un método se está ejecutando.'}
        </p>
      ) : (
        <div className="space-y-1">
          {frame.vars.map(([name, v]) => (
            <div
              key={name}
              className={cn(
                'flex items-center justify-between gap-3 rounded-lg bg-slate-800/50 px-2.5 py-1.5 font-mono text-xs',
                frame.changed.includes(`var:${name}`) && 'flash-bg ring-1 ring-yellow-400/60',
              )}
            >
              <span className="shrink-0">
                <span className="text-cyan-300/80">{varType(v)}</span> <span className="text-amber-200">{name}</span>
              </span>
              <span className="min-w-0 truncate">
                <VarValueView v={v} />
              </span>
            </div>
          ))}
        </div>
      )}
      <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-800 pt-3 font-mono text-xs">
        <div
          className={cn(
            'flex items-center justify-between rounded-lg bg-violet-500/10 px-2.5 py-1.5',
            frame.changed.includes('inicio') && 'flash-bg ring-1 ring-yellow-400/60',
          )}
        >
          <span className="text-violet-300">inicio</span>
          <AddrText addr={frame.state.inicio} />
        </div>
        <div
          className={cn(
            'flex items-center justify-between rounded-lg bg-violet-500/10 px-2.5 py-1.5',
            frame.changed.includes('fin') && 'flash-bg ring-1 ring-yellow-400/60',
          )}
        >
          <span className="text-violet-300">fin</span>
          <AddrText addr={frame.state.fin} />
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Mini reproductor flotante                                          */
/* ------------------------------------------------------------------ */

export function MiniPlayer({ pb, visible, onJump }: { pb: Playback; visible: boolean; onJump: () => void }) {
  const atEnd = pb.idx >= pb.total - 1;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-50 flex justify-center px-3">
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ y: 90, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 90, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="glass pointer-events-auto flex w-full max-w-[680px] items-center gap-2 rounded-2xl border border-slate-700 p-2 shadow-2xl shadow-black/60"
          >
            <span className="hidden shrink-0 rounded-md bg-yellow-400/15 px-2 py-1 font-mono text-[11px] font-bold text-yellow-300 sm:inline">
              {pb.idx + 1}/{pb.total}
            </span>
            <code className="min-w-0 flex-1 truncate font-mono text-xs">{highlightJava(pb.frame.title)}</code>
            <IconBtn title="Paso anterior" onClick={pb.prev} disabled={pb.idx === 0}>
              <StepBack size={15} />
            </IconBtn>
            <IconBtn title={pb.playing ? 'Pausa' : 'Reproducir'} onClick={pb.toggle}>
              {pb.playing ? <Pause size={15} /> : atEnd ? <RotateCcw size={15} /> : <Play size={15} />}
            </IconBtn>
            <IconBtn title="Paso siguiente" onClick={pb.next} disabled={atEnd}>
              <StepForward size={15} />
            </IconBtn>
            <IconBtn title="Ver el diagrama" onClick={onJump}>
              <ArrowUp size={15} />
            </IconBtn>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
