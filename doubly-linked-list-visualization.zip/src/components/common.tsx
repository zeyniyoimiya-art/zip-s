import { Fragment, useEffect, useRef, type ReactNode } from 'react';
import { CLASS_CODE, METHOD_CODE, type CodeLine, type MethodName } from '../lib/code';
import { LIST_ADDR, nodeColor } from '../lib/engine';
import { COLORS } from '../lib/theme';
import { cn } from '../utils/cn';

/* ------------------------------------------------------------------ */
/*  Resaltado de Java                                                  */
/* ------------------------------------------------------------------ */

const KEYWORDS = new Set([
  'public', 'private', 'protected', 'void', 'int', 'boolean', 'if', 'else', 'while', 'for',
  'return', 'new', 'null', 'true', 'false', 'break', 'class', 'this', 'package', 'import', 'static',
]);
const TYPES = new Set(['NodoDobleD', 'JOptionPane', 'ListaMetodoDoble', 'String', 'StringBuilder']);
const SPECIAL: Record<string, string> = {
  siguiente: 'text-emerald-300',
  anterior: 'text-orange-300',
  inicio: 'text-violet-300',
  fin: 'text-violet-300',
  nuevo: 'text-amber-300',
  actual: 'text-amber-300',
  dato: 'text-sky-300',
};

export function highlightJava(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\/\/.*$)|("(?:[^"\\]|\\.)*")|([A-Za-z_]\w*)|(\d+)/g;
  let last = 0;
  let k = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(<Fragment key={k++}>{text.slice(last, m.index)}</Fragment>);
    const tok = m[0];
    let cls = 'text-slate-200';
    if (m[1]) cls = 'text-slate-500 italic';
    else if (m[2]) cls = 'text-lime-300';
    else if (m[4]) cls = 'text-fuchsia-300';
    else if (KEYWORDS.has(tok)) cls = 'text-pink-400 font-semibold';
    else if (TYPES.has(tok)) cls = 'text-cyan-300';
    else if (SPECIAL[tok]) cls = SPECIAL[tok];
    else if (/^\s*\(/.test(text.slice(re.lastIndex))) cls = 'text-sky-300';
    out.push(
      <span key={k++} className={cls}>
        {tok}
      </span>,
    );
    last = re.lastIndex;
  }
  if (last < text.length) out.push(<Fragment key={k++}>{text.slice(last)}</Fragment>);
  return out;
}

/* ------------------------------------------------------------------ */
/*  Direcciones y texto enriquecido                                    */
/* ------------------------------------------------------------------ */

export function addrColor(addr: string): string {
  return addr === LIST_ADDR ? COLORS.list : nodeColor(addr);
}

export function AddrText({ addr, className }: { addr: string | null; className?: string }) {
  if (addr === null) return <span className={cn('font-mono text-slate-500', className)}>null</span>;
  return (
    <span className={cn('font-mono font-semibold', className)} style={{ color: addrColor(addr) }}>
      {addr}
    </span>
  );
}

const RICH_RE = /(\*\*[^*]+\*\*|`[^`]+`|0x[0-9A-F]{4})/g;

export function renderRich(text: string, keyPrefix = 'r'): ReactNode[] {
  return text.split(RICH_RE).map((p, i) => {
    const key = `${keyPrefix}-${i}`;
    if (!p) return null;
    if (p.startsWith('**') && p.endsWith('**') && p.length > 4)
      return (
        <strong key={key} className="font-semibold text-white">
          {renderRich(p.slice(2, -2), key)}
        </strong>
      );
    if (p.startsWith('`') && p.endsWith('`') && p.length > 2)
      return (
        <code key={key} className="rounded bg-slate-800/90 px-1.5 py-0.5 font-mono text-[0.86em] ring-1 ring-slate-700/70">
          {highlightJava(p.slice(1, -1))}
        </code>
      );
    if (/^0x[0-9A-F]{4}$/.test(p)) return <AddrText key={key} addr={p} />;
    return <Fragment key={key}>{p}</Fragment>;
  });
}

export function RichText({ text, className }: { text: string; className?: string }) {
  return <span className={className}>{renderRich(text)}</span>;
}

/* ------------------------------------------------------------------ */
/*  Bloques de código                                                  */
/* ------------------------------------------------------------------ */

function WindowBar({ title, right }: { title: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex items-center gap-3 border-b border-slate-800 bg-slate-900/80 px-4 py-2.5">
      <div className="flex gap-1.5">
        <span className="h-2.5 w-2.5 rounded-full bg-red-400/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
      </div>
      <div className="min-w-0 flex-1 truncate font-mono text-xs text-slate-400">{title}</div>
      {right}
    </div>
  );
}

export function CodeBlock({
  lines,
  title,
  activeIds = [],
  className,
  maxHeight,
}: {
  lines: CodeLine[] | string;
  title?: ReactNode;
  activeIds?: string[];
  className?: string;
  maxHeight?: number;
}) {
  const ls: CodeLine[] = typeof lines === 'string' ? lines.split('\n').map((text) => ({ text })) : lines;
  return (
    <div className={cn('overflow-hidden rounded-xl border border-slate-800 bg-[#0a0f1e] shadow-xl', className)}>
      {title && <WindowBar title={title} />}
      <div className="scroll-thin overflow-auto py-3" style={maxHeight ? { maxHeight } : undefined}>
        {ls.map((l, i) => {
          const active = !!l.id && activeIds.includes(l.id);
          return (
            <div
              key={i}
              className={cn(
                'flex border-l-2 border-transparent pr-4 font-mono text-[12.5px] leading-6',
                active && 'border-yellow-400 bg-yellow-400/10',
              )}
            >
              <span className="w-10 shrink-0 select-none pr-3 text-right text-slate-600">{i + 1}</span>
              <code className="whitespace-pre-wrap break-words">{l.text ? highlightJava(l.text) : ' '}</code>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function CodePanel({
  method,
  line,
  maxHeight = 460,
  className,
}: {
  method: MethodName | null;
  line: string;
  maxHeight?: number;
  className?: string;
}) {
  const lines = method ? METHOD_CODE[method] : CLASS_CODE;
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    const el = box.querySelector<HTMLElement>('[data-active="true"]');
    if (!el) {
      box.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const top = el.offsetTop - box.clientHeight / 2 + el.clientHeight / 2;
    box.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  }, [line, method]);

  return (
    <div className={cn('overflow-hidden rounded-2xl border border-slate-800 bg-[#0a0f1e] shadow-xl', className)}>
      <WindowBar
        title={
          <>
            ListaMetodoDoble.java <span className="text-slate-600">›</span>{' '}
            <span className="text-sky-300">{method ?? 'clase'}</span>
          </>
        }
        right={
          line ? (
            <span className="rounded-full bg-yellow-400/15 px-2 py-0.5 font-mono text-[10px] font-bold text-yellow-300">
              ejecutando
            </span>
          ) : null
        }
      />
      <div ref={boxRef} className="scroll-thin relative overflow-auto py-3" style={{ maxHeight }}>
        {lines.map((l, i) => {
          const active = !!line && !!l.id && (l.id === line || l.id === `${line}2`);
          return (
            <div
              key={`${method}-${i}`}
              data-active={active ? 'true' : undefined}
              className={cn(
                'relative flex border-l-[3px] border-transparent pr-3 font-mono text-[12px] leading-[22px] transition-colors duration-300',
                active && 'border-yellow-400 bg-yellow-400/[0.13]',
              )}
            >
              <span
                className={cn(
                  'w-9 shrink-0 select-none pr-2 text-right text-slate-600',
                  active && 'font-bold text-yellow-300',
                )}
              >
                {active ? '▶' : i + 1}
              </span>
              <code className="whitespace-pre-wrap break-words">{l.text ? highlightJava(l.text) : ' '}</code>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Layout                                                             */
/* ------------------------------------------------------------------ */

export function SectionHeader({
  id,
  num,
  kicker,
  title,
  children,
}: {
  id?: string;
  num: string;
  kicker: string;
  title: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div id={id} className="mb-8 max-w-3xl">
      <div className="mb-3 flex items-center gap-3">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 font-mono text-sm font-bold text-white shadow-lg shadow-violet-500/30">
          {num}
        </span>
        <span className="text-xs font-bold uppercase tracking-[0.2em] text-violet-300">{kicker}</span>
      </div>
      <h2 className="text-3xl font-black tracking-tight text-white sm:text-4xl">{title}</h2>
      {children && <div className="mt-4 text-base leading-relaxed text-slate-400">{children}</div>}
    </div>
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn('rounded-2xl border border-slate-800 bg-slate-900/50 p-5 shadow-xl shadow-black/20', className)}>
      {children}
    </div>
  );
}

export function Legend({ className }: { className?: string }) {
  const items: [string, ReactNode][] = [
    [COLORS.sig, 'siguiente →'],
    [COLORS.ant, '← anterior'],
    [COLORS.ptr, 'inicio / fin'],
    [COLORS.var, 'variables locales'],
    [COLORS.hl, 'recién cambiado'],
  ];
  return (
    <div className={cn('flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-slate-400', className)}>
      {items.map(([c, label], i) => (
        <span key={i} className="flex items-center gap-1.5">
          <span className="h-[3px] w-5 rounded-full" style={{ background: c }} />
          {label}
        </span>
      ))}
      <span className="flex items-center gap-1.5">
        <span className="h-3 w-4 rounded border border-dashed border-red-400" />
        inalcanzable (GC)
      </span>
    </div>
  );
}
